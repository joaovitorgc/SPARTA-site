let aulas = [];
let professores = [];
let alunos = [];

// login Admin

let admin = {
  email: "admin@gmail.com",
    senha: "admin123",
    nome: "Administrador"
};

// pagina do admin