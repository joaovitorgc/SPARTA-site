from flask import Flask, render_template, session, url_for

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('homesemusuario.html')

@app.route('/aulas_disponiveis')
def aulas_disponiveis():
    return render_template('aulas-disponiveis.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/homesemusuario')
def homesemusuario():
    return render_template('homesemusuario.html')

@app.route('/PaginaAdminCriandoaula')
def pagina_admin_criando_aula():
    return render_template('PaginaAdminCriandoaula.html')

@app.route('/PaginaProfessorAulas')
def pagina_professor_aulas():
    return render_template('PaginaProfessorAulas.html')

@app.route('/PaginaAlunoInscrições.html')
def pagina_aluno_inscricoes():
    return render_template('PaginaAlunoInscrições.html')

@app.route('/PaginaAdminProfessores')
def pagina_admin_professores():
    return render_template('PaginaAdminProfessores.html')

@app.route('/cadastro.html')
def cadastro():
    return render_template('cadastro.html')

@app.route('/pagina-aluno.html')
def pagina_aluno():
    return render_template('pagina-aluno.html')

@app.route('/editar-aula-admin.html')
def editar_aula_admin():
    return render_template('editar-aula-admin.html')

@app.route('/criaraula_admin.html')
def criar_aula_admin():
    return render_template('criaraula_admin.html')

@app.route('/PaginaAdminRelatórios')
def pagina_admin_relatorios():
    return render_template('PaginaAdminRelatórios.html')

@app.route('/homecomusuario.html')
def home_com_usuario():
    return render_template('homecomusuario.html')

@app.route('/editar-professor_admin.html')
def editar_professor_admin():
    return render_template('editar-professor_admin.html')

@app.route('/Cadastro-Professor.html')
def cadastro_professor():
    return render_template('Cadastro-Professor.html')

@app.route('/criaraula-professor.html')
def criar_aula_professor():
    return render_template('criaraula-professor.html')

@app.route('/editaraula-professor.html')
def editar_aula_professor():
    return render_template('editaraula-professor.html')

@app.route('/PaginaProfessorRelatorios.html')
def pagina_professor_relatorios():
    return render_template('PaginaProfessorRelatorios.html')

@app.route('/editar-admin.html')
def editar_admin():
    return render_template('editar-admin.html')





if __name__ == "__main__":
    app.run(debug=True)