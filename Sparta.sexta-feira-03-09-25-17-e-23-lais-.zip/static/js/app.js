document.addEventListener('DOMContentLoaded', function() {
  // Lista de usuários simulada
  // Redireciona pela extensão do email
  function getPaginaPorEmail(email) {
  if (email.endsWith('@admin')) return 'PaginaAdminRelatorios.html';
  if (email.endsWith('@aluno')) return 'pagina-aluno.html';
  if (email.endsWith('@professor')) return 'PaginaProfessorRelatorios.html';
    return null;
  }
  // Adiciona alerta customizado ao body
  var customAlert = document.createElement('div');
  customAlert.id = 'custom-alert';
  customAlert.style.display = 'none';
  customAlert.innerHTML = '<div id="custom-alert-title" style="font-size:1.3rem;margin-bottom:10px;"></div><span id="custom-alert-message"></span><div id="custom-alert-actions" style="display:none;margin-top:18px;"><button id="custom-alert-yes" style="background:#000;color:#fff;margin-right:10px;">Sim</button><button id="custom-alert-no" style="background:#8B0000;color:#fff;">Não</button></div><br><button id="custom-alert-close">OK</button>';
  document.body.appendChild(customAlert);

  function showCustomAlert(message, title, showActions, onYes) {
    document.getElementById('custom-alert-title').textContent = title || 'Ação inválida';
    document.getElementById('custom-alert-message').textContent = message;
    var actions = document.getElementById('custom-alert-actions');
    var closeBtn = document.getElementById('custom-alert-close');
    actions.style.display = showActions ? 'flex' : 'none';
    closeBtn.style.display = showActions ? 'none' : 'inline-block';
    // Alerta branco só na confirmação
    if (showActions && title === 'Confirmação') {
      customAlert.style.background = '#fff';
      customAlert.style.color = '#222';
      customAlert.style.border = '2px solid #8B0000';
    } 
    else if (title === 'Sucesso') {
    customAlert.style.background = '#28a745'; // verde
    customAlert.style.color = '#fff';
    customAlert.style.border = 'none';
    closeBtn.style.background = '#218838'; 
    closeBtn.style.color = '#fff';
    }
    else {
      customAlert.style.background = '#8B0000';
      customAlert.style.color = '#fff';
      customAlert.style.border = 'none';
    }
    customAlert.style.display = 'flex';
    if (showActions) {
      document.getElementById('custom-alert-yes').onclick = function() {
        customAlert.style.display = 'none';
        if (onYes) onYes();
      };
      document.getElementById('custom-alert-no').onclick = function() {
        customAlert.style.display = 'none';
      };
    }
  }
  document.getElementById('custom-alert-close').onclick = function() {
    customAlert.style.display = 'none';
  };
  var forms = document.querySelectorAll('form');
  forms.forEach(function(form) {
    form.addEventListener('submit', function(e) {
      var senha = form.querySelector('input[type="password"]');
      var confirmarSenha = form.querySelector('#confirmar-senha');
      var senhaValor = senha ? senha.value : '';
      var confirmarValor = confirmarSenha ? confirmarSenha.value : senhaValor;
      // Nova regex: mínimo 1 maiúscula, 1 número, 1 especial
      var regex = /^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).+/;

      if (!regex.test(senhaValor)) {
        e.preventDefault();
        showCustomAlert('Sua senha deve conter pelo menos uma letra maiúscula, um número e um caractere especial (!, @, #, $ e %.).', 'Ação inválida');
      } else if (senhaValor !== confirmarValor) {
        e.preventDefault();
        showCustomAlert('As senhas não coincidem. Por favor, digite-as novamente.', 'Ação inválida');
      } else {
        var emailInput = form.querySelector('input[type="email"]');
        var emailValor = emailInput ? emailInput.value : '';
        // Se for login, faz confirmação antes do redirecionamento
        if (window.location.pathname.endsWith('login.html')) {
          var pagina = getPaginaPorEmail(emailValor);
          if (!pagina) {
            e.preventDefault();
            showCustomAlert('Senha ou Email inválidos', 'Ação inválida');
          } else {
            e.preventDefault();
            showCustomAlert('Tem certeza de que deseja finalizar seu Login?', 'Confirmação', true, function() {
              showCustomAlert('Login realizado com sucesso!', 'Sucesso');
              setTimeout(function() {
                window.location.href = pagina;
              }, 1200);
            });
          }
        
        } else {
          // Cadastro comum ou cadastro professor
          // Exemplo de validação: email deve terminar com @admin, @aluno ou @professor
          if (!getPaginaPorEmail(emailValor)) {
            e.preventDefault();
            showCustomAlert('Ação inválida: Credenciais inválidas! O email deve terminar com @admin, @aluno ou @professor.', 'Ação inválida');
          } 
          
          else if (senhaValor !== confirmarValor) {
            e.preventDefault();
        showCustomAlert('As senhas não coincidem. Por favor, digite-as novamente.', 'Ação inválida');}

          else {
            e.preventDefault();
            showCustomAlert('Tem certeza de que deseja finalizar seu Cadastro?', 'Confirmação', true, function() {
              // Impede envio do formulário, não faz submit
              showCustomAlert('Cadastro realizado com sucesso!', 'Sucesso');
            });
          }
        }
      }
    });
  });
});

document.getElementById('abrir-menu').onclick = function() {
    document.getElementById('menu-js').style.display = 'block';
};
document.getElementById('fechar-menu').onclick = function() {
    document.getElementById('menu-js').style.display = 'none';
};

