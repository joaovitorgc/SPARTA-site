from flask import Flask, render_template, session, url_for, redirect, flash, url_for, request
import fdb
from flask_bcrypt import generate_password_hash, check_password_hash


app = Flask(__name__)
app.secret_key = 'sparta'

# Configurações do banco de dados
host = 'localhost'
database = r'C:\Users\Aluno\Desktop\BANCO\SPARTA.FDB'
user = 'sysdba'
password = 'sysdba'

con = fdb.connect(host=host, database=database, user=user, password=password)

@app.route('/')
def index():
    return render_template('homesemusuario.html')

@app.route('/aulas_disponiveis')
def aulas_disponiveis():
    return render_template('aulas-disponiveis.html')

@app.route('/abrir_login')
def abrir_login():
    return render_template('login.html')

@app.route('/editaraluno')
def editaraluno():
    return render_template('editar-aluno.html')

@app.route('/homesemusuario')
def homesemusuario():
    return render_template('homesemusuario.html')

@app.route('/nav_perfis')
def nav_perfis():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1:
        return redirect(url_for('pagina_aluno_inscricoes'))
    elif session['usuario'][6] == 2:
        return redirect(url_for('pagina_professor_aulas'))
    else:
        return redirect(url_for('pagina_admin_usuarios'))

@app.route('/PaginaAdminCriandoaula')
def pagina_admin_criando_aula():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    dias = {
        'domingo': [],
        'segunda': [],
        'terca': [],
        'quarta': [],
        'quinta': [],
        'sexta': [],
        'sabado': []
    }

    try:
        cursor = con.cursor()

        for i, dia in enumerate(dias):
            cursor.execute(f'''SELECT ID_AULA AS ID
                                    , m.DESCRICAO
                                    , HORA_AULA
                                    , HORA_TERMINO
                                    , LOTACAO
                                    , u.NOME
                                    FROM AULAS a
                                    INNER JOIN USUARIO u ON u.ID_USUARIO = a.ID_USUARIO
                                    INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
                                    WHERE {dia.lower()} = 1''')
            dias[dia] = cursor.fetchall()

    except Exception as e:
        flash(("Houve um erro ao obter as aulas:", e), 'error')
    finally:
        cursor.close()

    return render_template('PaginaAdminCriandoaula.html', aulas=dias)


@app.route('/PaginaProfessorAulas')
def pagina_professor_aulas():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    aulasObtidas = []

    try:
        cursor = con.cursor()
        cursor.execute("SELECT * FROM AULAS ")
        aulas = cursor.fetchall()
        cursor.close()
    except Exception as e:
        print(e)
        flash("Não foi possível obter as aulas", "error")

    return render_template('PaginaProfessorAulas.html', aulasObtidas=aulas)

@app.route('/PaginaAlunoInscrições')
def pagina_aluno_inscricoes():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    return render_template('PaginaAlunoInscrições.html')

@app.route('/PaginaAdminProfessores')
def pagina_admin_professores():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    professores = []
    cursor = con.cursor()

    try:
        cursor.execute("SELECT * FROM USUARIO WHERE TIPO = 2")
        professores = cursor.fetchall()
    except Exception as e:
        flash("Houve um erro ao obter os professores.", 'error')
    finally:
        cursor.close()

    return render_template('PaginaAdminProfessores.html', professoresObtidos=professores)

@app.route('/cadastro')
def cadastro():
    return render_template('cadastro.html')

@app.route('/pagina-aluno')
def pagina_aluno():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    return render_template('pagina-aluno.html')

@app.route('/editar-aula-admin/<int:id_aula>', methods=['GET', 'POST'])
def editar_aula_admin(id_aula):
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()

    if request.method == 'GET':
        aula = None
        modalidades = []
        professores = []
        try:
            cursor.execute("SELECT ID_AULA, ID_MODALIDADE, DOMINGO, SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO, HORA_AULA, HORA_TERMINO, LOTACAO, ID_USUARIO FROM AULAS WHERE ID_AULA = ?", (id_aula,))
            aula = cursor.fetchone()

            cursor.execute("SELECT id_modalidade, descricao FROM MODALIDADES")
            modalidades = cursor.fetchall()

            cursor.execute("SELECT id_usuario, nome FROM USUARIO WHERE TIPO = 2")
            professores = cursor.fetchall()
        except Exception as e:
            flash("Houve um erro ao obter os dados da aula.", 'error')
        finally:
            cursor.close()

        return render_template(
'editaraula-admin.html',
            aula=aula,
            modalidadesObtidas=modalidades,
            professoresObtidos=professores)

@app.route('/criaraula_admin', methods=['GET', 'POST'])
def criar_aula_admin():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()

    if request.method == "GET":
        modalidades = []
        professores = []
        try:
            cursor.execute("SELECT id_modalidade, descricao FROM MODALIDADES")
            modalidades = cursor.fetchall()
            cursor.execute("SELECT id_usuario, NOME FROM USUARIO WHERE TIPO = 2")
            professores = cursor.fetchall()
        except Exception as e:
            flash("Houve um erro ao obter os dados para criar a aula.", 'error')
        return render_template('criaraula-admin.html', professoresObtidos=professores, modalidadesObtidas=modalidades)

    elif request.method == "POST":
        try:
            # Captura dos dados do formulário
            modalidade = request.form['modalidade']
            professor = request.form['professor']
            dia_da_aula = request.form['data-aula']
            horario = request.form['horario']
            horario_termino = request.form['horario_termino']  # Campo de término
            vagas = request.form['vagas']

            # Mapeando os dias para as colunas no banco
            day_mapping = {
                'domingo': 'DOMINGO',
                'segunda': 'SEGUNDA',
                'terca': 'TERCA',
                'quarta': 'QUARTA',
                'quinta': 'QUINTA',
                'sexta': 'SEXTA',
                'sabado': 'SABADO'
            }

            # Pegando a coluna correspondente ao dia
            dia_coluna = day_mapping.get(dia_da_aula)

            if not dia_coluna:
                flash("Dia inválido.", 'error')
                return redirect(url_for('criar_aula_admin'))

            # Consultar ID da modalidade
            cursor.execute("SELECT id_modalidade FROM MODALIDADES WHERE DESCRICAO = ?", (modalidade.capitalize(),))
            modalidade_id = cursor.fetchone()

            print(modalidade_id)

            # Consultar ID do professor
            cursor.execute("SELECT id_usuario FROM USUARIO WHERE id_usuario = ?", (professor,))
            professor_id = cursor.fetchone()

            print(professor_id)

            if not modalidade_id or not professor_id:
                flash("Modalidade ou professor não encontrados.", 'error')
                return redirect(url_for('criar_aula_admin'))

            # Inserir os dados no banco
            cursor.execute('''
                INSERT INTO AULAS (ID_MODALIDADE, DOMINGO, SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO, HORA_AULA, HORA_TERMINO, LOTACAO, ID_USUARIO)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (modalidade_id[0], 1 if dia_coluna == 'DOMINGO' else 0, 1 if dia_coluna == 'SEGUNDA' else 0,
                  1 if dia_coluna == 'TERCA' else 0, 1 if dia_coluna == 'QUARTA' else 0,
                  1 if dia_coluna == 'QUINTA' else 0, 1 if dia_coluna == 'SEXTA' else 0,
                  1 if dia_coluna == 'SABADO' else 0, horario, horario_termino, vagas, professor_id[0]))

            con.commit()
            flash("Aula cadastrada com sucesso!", 'success')
        except Exception as e:
            con.rollback()
            flash((f"Houve um erro ao criar a aula. Tente novamente: {e}"), 'error')
            print(e)  # Logar o erro para debug
        finally:
            cursor.close()

        return redirect(url_for('pagina_admin_criando_aula'))


@app.route('/PaginaAdminRelatórios')
def pagina_admin_relatorios():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    return render_template('PaginaAdminRelatorios.html')

@app.route('/homecomusuario')
def home_com_usuario():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    return render_template('homecomusuario.html')

@app.route('/aulas-disponiveis-sem-usuario.html')
def aulas_disponiveis_sem_usuario():
    return render_template('aulas-disponiveis-sem-usuario.html')

@app.route('/editar-professor_admin/<int:id_usuario>', methods=['GET', 'POST'])
def editar_professor_admin(id_usuario):
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if request.method == 'GET':
        cursor = con.cursor()
        cursor.execute("SELECT ID_USUARIO, NOME, EMAIL, SENHA, TELEFONE, CPF, MODALIDADE FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
        professor = cursor.fetchone()

        cursor.execute("SELECT id_modalidade, descricao FROM MODALIDADES")
        modalidades = cursor.fetchall()

        return render_template('editar-professor_admin.html', professor=professor, modalidadesObtidas=modalidades)

    try:
        nome = request.form.get('nome')
        email = request.form.get('email')
        especialidade = request.form.get('especialidade')
        cpf = request.form.get('cpf')
        telefone = request.form.get('telefone')
        senha = request.form.get('senha')

        cursor = con.cursor()

        if senha:  # Só atualiza a senha se foi preenchida
            cursor.execute('''UPDATE USUARIO SET 
                NOME = ?,
                EMAIL = ?,
                MODALIDADE = ?,
                CPF = ?,
                TELEFONE = ?,
                SENHA = ?
                WHERE ID_USUARIO = ?''',
                           (nome, email, especialidade, cpf, telefone, generate_password_hash(senha).decode('utf-8'),
                            id_usuario))
            con.commit()

        else:  # Senha não foi preenchida, então não atualiza esse campo
            cursor.execute('''UPDATE USUARIO SET 
                NOME = ?,
                EMAIL = ?,
                MODALIDADE = ?,
                CPF = ?,
                TELEFONE = ?
                WHERE ID_USUARIO = ?''',
                           (nome, email, especialidade, cpf, telefone, id_usuario))

            con.commit()
        flash("Professor atualizado com sucesso.", 'success')
    except Exception as e:
        flash("Houve um erro ao atualizar o professor.", 'error')
    finally:
        cursor.close()

    return redirect(url_for('pagina_admin_professores'))


@app.route('/Cadastro-Professor.html')
def cadastro_professor():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()
    cursor.execute("SELECT id_modalidade, descricao FROM MODALIDADES")
    modalidades = cursor.fetchall()

    return render_template('Cadastro-Professor.html', modalidadesObtidas=modalidades)

@app.route('/criaraula-professor.html')
def criar_aula_professor():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()
    cursor.execute("SELECT id_modalidade, descricao FROM MODALIDADES")
    modalidades = cursor.fetchall()
    cursor.execute("SELECT id_usuario, NOME FROM USUARIO WHERE TIPO = 2")
    professores = cursor.fetchall()

    id_modalidade = request.form.get('especialidade')
    professor = request.form.get('professor')
    data_aula = request.form.get('data-aula')
    horario = request.form.get('horario')
    vagas = request.form.get('vagas')

    cursor.execute('''INSERT INTO AULAS (ID_MODALIDADE, ID_USUARIO, HORA_AULA, LOTACAO''')




    return render_template('PaginaProfessorAulas.html', modalidadesObtidas=modalidades, professoresObtidos=professores)

@app.route('/editaraula-professor.html')
def editar_aula_professor():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    # cursor = con.cursor()
    # cursor.execute("SELECT")

    return render_template('editaraula-professor.html')

@app.route('/PaginaProfessorRelatorios.html')
def pagina_professor_relatorios():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    return render_template('PaginaProfessorRelatorios.html')

@app.route('/editar-admin.html')
def editar_admin():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    return render_template('editar-admin.html')

@app.route('/cadastro_modalidade')
def cadastro_modalidade():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    return render_template('criar-modalidades.html')

@app.route('/pagina_admin_modalidades')
def pagina_admin_modalidades():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    return render_template('PaginaAdminModalidades.html')

@app.route('/excluiraula/<int:id_aula>')
def excluir_aula(id_aula):
    if not 'usuario' in session:
        return redirect(url_for('login'))
    cursor = con.cursor()
    try:
        cursor.execute("DELETE FROM AULAS WHERE ID_AULA = ?", (id_aula,))
        con.commit()
    except Exception as e:
        flash("Houve um erro ao excluir a aula.", 'error')
    finally:
        cursor.close()
        flash("Aula excluída com sucesso.", 'success')
        if session['usuario'][6] == 0:
            return redirect(url_for('pagina_admin_criando_aula'))
        else:
            return redirect(url_for('pagina_professor_aulas'))



@app.route('/criar_modalidade', methods=["POST"])
def criar_modalidade():
    descricao = request.form['nome-modalidade']
    situacao = request.form['situacao']
    cursor = con.cursor()

    try:
        cursor.execute('SELECT 1 FROM MODALIDADES WHERE DESCRICAO = ?', (descricao,))
        if cursor.fetchone():
            flash('Essa modalidade já está cadastrada.', "error")
            return redirect(url_for('cadastro_modalidade'))

        cursor.execute('''
            INSERT INTO MODALIDADES (DESCRICAO, SITUACAO)
            VALUES (?, ?)
        ''', (descricao, situacao))

        con.commit()
        flash('Modalidade cadastrada com sucesso.', 'success')

    finally:
        cursor.close()

    return redirect(url_for('carregar_modalidades'))


@app.route('/criarusuario', methods=["POST"])
def criarusuario():
    nome = request.form['nome']
    email = request.form['email']
    senha = request.form['senha']
    telefone = request.form['telefone']
    confirmarSenha = request.form['confirmar-senha']
    cpf = request.form['CPF']
    cursor = con.cursor()

    if confirmarSenha != senha:
        flash("As senhas não coincidem", "error")
        return redirect(url_for('cadastro'))

    senha_forte()

    # Verificação de senha forte
    if not (senha):
        flash('A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.', "error")
        return redirect(url_for('cadastro'))

    try:
        cursor.execute('SELECT 1 FROM USUARIO WHERE EMAIL = ?', (email,))
        if cursor.fetchone():
            flash('Esse usuário já está cadastrado.', "error")
            return redirect(url_for('cadastro'))

        senha_hash = generate_password_hash(senha).decode('utf-8')
        cursor.execute('''
            INSERT INTO USUARIO (NOME, EMAIL, SENHA, TELEFONE, CPF, TIPO, TENTATIVAS, SITUACAO)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (nome, email, senha_hash, telefone, cpf, 1, 0, 0))

        con.commit()
        flash('Usuário cadastrado com sucesso.', 'success')

    finally:
        cursor.close()

    return redirect(url_for('cadastro'))

@app.route('/abrir_cadastro_admin')
def cadastro_admin():
    return render_template('cadastro-admin.html')

def senha_forte(senha):
    if len(senha) < 8:
        return False
    tem_maiuscula = any(c.isupper() for c in senha)
    tem_minuscula = any(c.islower() for c in senha)
    tem_numero = any(c.isdigit() for c in senha)
    tem_especial = any(not c.isalnum() for c in senha)
    return tem_maiuscula and tem_minuscula and tem_numero and tem_especial


@app.route('/criarusuario_admin', methods=["POST"])
def criarusuario_admin():
    nome = request.form['nome']
    email = request.form['email']
    senha = request.form['senha']
    confirmarSenha = request.form['confirmar-senha']
    telefone = request.form['telefone']
    cpf = request.form['CPF']
    cursor = con.cursor()

    if confirmarSenha != senha:
        flash("As senhas não coincidem", "error")
        return redirect(url_for('criarusuario_admin'))

    # Verificação de senha forte
    senha_forte(senha)
    if not senha_forte(senha):
        flash(
            'A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.',
            "error")
        return redirect(url_for('cadastro_admin'))
    if not senha_forte(senha):
        flash('A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.',"error")
        return redirect(url_for('cadastro'))

    if not senha_forte(senha):
        flash('A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.', "error")
        return redirect(url_for('cadastro'))

    try:
        cursor.execute('SELECT 1 FROM USUARIO WHERE EMAIL = ?', (email,))
        if cursor.fetchone():
            flash('Esse usuário já está cadastrado.', "error")
            return redirect(url_for('cadastro'))

        senha_hash = generate_password_hash(senha).decode('utf-8')
        cursor.execute('''
            INSERT INTO USUARIO (NOME, EMAIL, SENHA, TELEFONE, CPF, TIPO, TENTATIVAS, SITUACAO)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (nome, email, senha_hash, telefone, cpf, 1, 0, 0))

        con.commit()
        flash('Usuário cadastrado com sucesso.', 'success')

    finally:
        cursor.close()

    return redirect(url_for('pagina_admin_usuarios'))

#Cadastro de professor (o admin cadastra o professor)
@app.route('/cadastro_professor', methods=["POST"])
def criar_professor():
    nome = request.form['nome']
    email = request.form['email']
    senha = request.form['senha']
    confirmarSenha = request.form['confirmar-senha']
    telefone = request.form['telefone']
    cpf = request.form['CPF']
    modalidade = request.form['especialidade']
    cursor = con.cursor()

    if confirmarSenha != senha:
        flash("As senhas não coincidem", "error")
        return redirect(url_for('cadastro_professor'))

    # Verificação de senha
    if not senha_forte(senha):
        flash('A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.', "error")
        return redirect(url_for('cadastro_professor'))
    try:
        cursor.execute('SELECT 1 FROM USUARIO WHERE EMAIL = ?', (email,))
        if cursor.fetchone():
            flash('Esse usuário já está cadastrado.', "error")
            return redirect(url_for('cadastro_professor'))

        senha_hash = generate_password_hash(senha).decode('utf-8')
        cursor.execute('''
            INSERT INTO USUARIO (NOME, EMAIL, SENHA, TELEFONE, CPF, TIPO, TENTATIVAS, SITUACAO, MODALIDADE)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (nome, email, senha_hash, telefone, cpf, 2, 0, 0, modalidade))

        con.commit()
        flash('Professor cadastrado com sucesso.', 'success')

    finally:
        cursor.close()

    return redirect(url_for('pagina_admin_professores'))

# Edição de usuário
@app.route('/editarusuario/<int:id_usuario>', methods=['GET', 'POST'])
def editarusuario(id_usuario):
    if not 'usuario' in session:
        return redirect(url_for('login'))

    cursor = con.cursor()
    cursor.execute("SELECT ID_USUARIO, NOME, EMAIL, SENHA, TELEFONE, CPF FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
    usuario = cursor.fetchone()
    cursor.close()

    if not usuario:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for('editaraluno'))

    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']
        telefone = request.form['telefone']
        cpf = request.form['CPF']

        if senha:
            senha_forte(senha)
            if not senha_forte(senha):
                flash(
                    'A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.',
                    "error")
                return redirect(url_for('pagina_aluno', id_usuario=id_usuario))
            hash_senha = generate_password_hash(senha).decode('utf-8')

        else:
            hash_senha = usuario[3]


        cursor = con.cursor()
        cursor.execute("UPDATE USUARIO SET NOME = ?, EMAIL = ?, SENHA = ?, TELEFONE = ?, CPF = ? WHERE ID_USUARIO = ?",
                       (nome, email, hash_senha, telefone, cpf, id_usuario))
        con.commit()
        cursor.close()



        # atualiza
        cursor.execute('''SELECT 
                        ID_USUARIO, 
                        NOME,
                        EMAIL,
                        TELEFONE, 
                        SENHA, 
                        CPF, 
                        TIPO 
         FROM USUARIO WHERE EMAIL = ?''', (email,))

        session['usuario'] = cursor.fetchone() # Atualiza a sessão com os novos dados

        flash("Usuário atualizado com sucesso.", 'success')
        if session['usuario'][6] == 2:
            return redirect(url_for('pagina_professor_aulas'))
        else:
            return redirect(url_for('pagina_aluno'))

    return render_template('editar-aluno.html', usuario=usuario, titulo='Editar Usuário')

    # Login de usuário

# Edição de usuário-admin
@app.route('/editarusuario_admin/<int:id_usuario>', methods=['GET', 'POST'])
def editarusuario_admin(id_usuario):
    if not 'usuario' in session:
        return redirect(url_for('login'))

    cursor = con.cursor()
    cursor.execute("SELECT ID_USUARIO, NOME, EMAIL, SENHA, TELEFONE, CPF FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
    usuario = cursor.fetchone()
    cursor.close()

    if not usuario:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for('editaraluno'))

    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']
        telefone = request.form['telefone']
        cpf = request.form['CPF']



        if senha:
            senha_forte(senha)
            if not senha_forte(senha):
                flash(
                    'A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.',
                    "error")
                return redirect(url_for('editarusuario_admin', id_usuario=id_usuario))
            hash_senha = generate_password_hash(senha).decode('utf-8')

        else:
            hash_senha = usuario[3]


        cursor = con.cursor()
        cursor.execute("UPDATE USUARIO SET NOME = ?, EMAIL = ?, SENHA = ?, TELEFONE = ?, CPF = ? WHERE ID_USUARIO = ?",
                       (nome, email, hash_senha, telefone, cpf, id_usuario))
        con.commit()
        cursor.close()

        # atualiza
        cursor.execute('''SELECT 
                        ID_USUARIO, 
                        NOME,
                        EMAIL,
                        TELEFONE, 
                        SENHA, 
                        CPF, 
                        TIPO 
         FROM USUARIO WHERE EMAIL = ?''', (email,))

        usuario = cursor.fetchone() # Atualiza a sessão com os novos dados

        if usuario[0] == session['usuario'][0]:
            session['usuario'] = usuario

        # print(session['usuario'])

        flash("Usuário atualizado com sucesso.", 'success')
        return redirect(url_for('pagina_admin_usuarios'))

    return render_template('editar-aluno-admin.html', usuario=usuario, titulo='Editar Usuário')



@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        cursor = con.cursor()

        try:
            # Busca apenas pela senha criptografada com base no e-mail
            cursor.execute('''SELECT 
                            ID_USUARIO, 
                            NOME,
                            EMAIL,
                            TELEFONE, 
                            SENHA, 
                            CPF, 
                            TIPO, TENTATIVAS, SITUACAO
             FROM USUARIO WHERE EMAIL = ?''', (email,))
            usuario = cursor.fetchone()

            if not usuario:
                flash('Usuário não encontrado.', "error")
                return redirect(url_for('login'))

            if usuario[8] == 1:
                flash('Usuario esta bloqueado', "error")
                return redirect(url_for('login'))

            senha_armazenada = usuario[4]  # A senha criptografada no banco

            if check_password_hash(senha_armazenada, senha):
                session['usuario'] = usuario  # Armazena o e-mail na sessão
                cursor.execute('UPDATE USUARIO SET TENTATIVAS = 0 WHERE ID_USUARIO = ?', (usuario[0],))
                con.commit()
                flash('Login realizado com sucesso.', "success")

                if usuario[6] == 0:
                    return redirect(url_for('pagina_admin_usuarios'))
                elif usuario[6] == 2:
                    return redirect(url_for('pagina_professor_aulas'))
                else:
                    return redirect(url_for('pagina_aluno_inscricoes'))

            else:
                cursor.execute('''UPDATE USUARIO SET TENTATIVAS = TENTATIVAS + 1 WHERE ID_USUARIO = ?''', (usuario[0],))
                con.commit()

                tentativas = usuario[7]
                if tentativas >= 2:
                    cursor.execute('UPDATE USUARIO SET SITUACAO = 1 WHERE ID_USUARIO = ?', (usuario[0],))
                    con.commit()
                    flash('Conta bloqueada devido a múltiplas tentativas de login falhadas.', "error")
                    return redirect(url_for('login'))

                else:
                    flash('Você tem {} tentativas restantes.'.format(2 - tentativas), "error")

                flash('Senha incorreta.', "error")
                return redirect(url_for('login'))



        finally:
            cursor.close()

    return render_template('login.html')

@app.route('/logout')
def logout():
    if 'usuario' in session:
        session.pop('usuario', None)
    flash('Você saiu da sua conta.', 'success')
    return redirect(url_for('index'))

@app.route('/pagina_admin_usuarios')
def pagina_admin_usuarios():
    usuariosObtidos = []

    try:
        cursor = con.cursor()
        cursor.execute("SELECT * FROM USUARIO")
        usuariosObtidos = cursor.fetchall()
        cursor.close()
    except Exception as e:
        flash("Houve um erro ao obter usuários.", 'error')

    return render_template('PaginaAdminUsuarios.html', usuariosObtidos=usuariosObtidos)

@app.route('/carregar_modalidades')
def carregar_modalidades():
    modalidades = []
    try:
        cursor = con.cursor()
        cursor.execute("SELECT * FROM MODALIDADES")
        modalidades = cursor.fetchall()
        cursor.close()
    except Exception as e:
        flash("Houve um erro ao obter as modalidades.", 'error')
    return render_template('PaginaAdminModalidades.html', modalidadesObtidas=modalidades)

@app.route('/excluirmodalidade/<int:id_modalidade>')
def excluir_modalidade(id_modalidade):
    if not 'usuario' in session:
        return redirect(url_for('login'))
    cursor = con.cursor()
    try:
        cursor.execute("DELETE FROM MODALIDADES WHERE ID_MODALIDADE = ?", (id_modalidade,))
        con.commit()
    except Exception as e:
        flash("Houve um erro ao excluir a modalidade.", 'error')
    finally:
        cursor.close()
    return redirect(url_for('carregar_modalidades'))

@app.route('/editar_modalidade/<int:id_modalidade>', methods=['GET', 'POST'])
def editar_modalidade(id_modalidade):
    cursor = con.cursor()

    if request.method == 'GET':
        cursor.execute("SELECT ID_MODALIDADE, DESCRICAO, SITUACAO FROM MODALIDADES WHERE ID_MODALIDADE = ?",
                           (id_modalidade,))
        modalidade = cursor.fetchone()
        cursor.close()

        if not modalidade:
            flash("Modalidade não encontrada.", "error")
            return redirect(url_for('carregar_modalidades'))

        return render_template('editar_modalidade.html', modalidade=modalidade, titulo='Editar Modalidade')

    nomeModalidade = request.form['nome-modalidade']
    situacao = request.form['situacao']

    cursor.execute("UPDATE MODALIDADES SET DESCRICAO = ?, SITUACAO = ? WHERE ID_MODALIDADE = ?",
                   (nomeModalidade, situacao, id_modalidade))
    return redirect(url_for('carregar_modalidades'))

@app.route('/excluiraluno/<int:id_usuario>')
def excluir_aluno(id_usuario):
    print(id_usuario)
    if not 'usuario' in session:
        return redirect(url_for('login'))

    if not session['usuario'][6] == 0:  # Verifica se o usuário é admin
        flash("Acesso negado. Apenas administradores podem excluir usuários.", 'error')
        return redirect(url_for('pagina_admin_usuarios'))

    try:
        cursor = con.cursor()
        cursor.execute("DELETE FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
        con.commit()
        cursor.close()
    except Exception as e:
        flash("Houve um erro ao excluir o usuário.", 'error')
    return redirect(url_for('pagina_admin_usuarios'))

@app.route('/excluir_professor/<int:id_usuario>')
def excluir_professor(id_usuario):
    if not 'usuario' in session:
        return redirect(url_for('login'))

    if not session['usuario'][6] == 0:  # Verifica se o usuário é admin
        flash("Acesso negado. Apenas administradores podem excluir professores.", 'error')
        return redirect(url_for('pagina_admin_professores'))

    try:
        cursor = con.cursor()
        cursor.execute("DELETE FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
        con.commit()
        cursor.close()
    except Exception as e:
        flash("Houve um erro ao excluir o usuário.", 'error')
    return redirect(url_for('pagina_admin_professores'))





if __name__ == "__main__":
    app.run(debug=True)