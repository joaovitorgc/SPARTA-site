from flask import Flask, render_template, session, redirect, flash, url_for, request, send_file
import fdb
from flask_bcrypt import generate_password_hash, check_password_hash
from fpdf import FPDF
from datetime import datetime



app = Flask(__name__)
app.secret_key = 'sparta'

# Configurações do banco de dados
host = 'localhost'
database = r'C:\Users\Aluno\Desktop\SPARTA.FDB'
user = 'sysdba'
password = 'sysdba'

con = fdb.connect(host=host, database=database, user=user, password=password)

@app.route('/')
def index():
    return render_template('homesemusuario.html')

@app.route('/aulas_disponiveis')
def aulas_disponiveis():
    return render_template('aulas-disponiveis.html')

@app.route('/abrir_login')
def abrir_login():
    return render_template('login.html')

@app.route('/editaraluno')
def editaraluno():
    return render_template('editar-aluno.html')

@app.route('/homesemusuario')
def homesemusuario():
    return render_template('homesemusuario.html')

@app.route('/nav_perfis')
def nav_perfis():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1:
        return redirect(url_for('pagina_aluno_inscricoes'))
    elif session['usuario'][6] == 2:
        return redirect(url_for('pagina_professor_aulas'))
    else:
        return redirect(url_for('pagina_admin_usuarios'))

@app.route('/PaginaAdminCriandoaula')
def pagina_admin_criando_aula():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    dias = {
        'domingo': [],
        'segunda': [],
        'terca': [],
        'quarta': [],
        'quinta': [],
        'sexta': [],
        'sabado': []
    }

    cursor = con.cursor()

    try:
        for i, dia in enumerate(dias):
            cursor.execute(f'''
            SELECT a.ID_AULA AS ID,
                m.DESCRICAO,
                HORA_AULA,
                HORA_TERMINO,
                LOTACAO,
                u.NOME,
                m.COR,
                COUNT(ia.ID_INSCRICAO_ALUNO) AS NUM_INSCRICOES
            FROM AULAS a
            INNER JOIN USUARIO u ON u.ID_USUARIO = a.ID_USUARIO
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE {dia.upper()} = 1
            GROUP BY a.ID_AULA, m.DESCRICAO, HORA_AULA, HORA_TERMINO, LOTACAO, u.NOME, m.COR
            ''')
            dias[dia] = cursor.fetchall()
    except Exception as e:
        flash(("Houve um erro ao obter as aulas:", e), 'error')
    finally:
        cursor.close()

    # Conta o total de professores (TIPO = 2)
    cursor = con.cursor()
    cursor.execute("SELECT COUNT(*) FROM USUARIO WHERE TIPO = 2")
    total_professores = cursor.fetchone()[0]

    # Conta o total de aulas
    cursor.execute("SELECT COUNT(*) FROM AULAS")
    total_aulas = cursor.fetchone()[0]

    # Conta o total de inscritos
    cursor.execute("SELECT COUNT(*) FROM INSCRICOES_ALUNO")
    total_inscricoes = cursor.fetchone()[0]

    return render_template('PaginaAdminCriandoaula.html', aulas=dias, professoresObtidos=total_professores, aulasObtidas=total_aulas, total_inscricoes=total_inscricoes)



@app.route('/PaginaProfessorAulas')
def pagina_professor_aulas():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 0:
        flash("Acesso negado. Você não é um Professor", 'error')
        return redirect(url_for('login'))

    dias = {
        'domingo': [],
        'segunda': [],
        'terca': [],
        'quarta': [],
        'quinta': [],
        'sexta': [],
        'sabado': []
    }

    cursor = con.cursor()

    try:
        for i, dia in enumerate(dias):
            cursor.execute(f'''
                SELECT a.ID_AULA AS ID,
                    m.DESCRICAO,
                    HORA_AULA,
                    HORA_TERMINO,
                    LOTACAO,
                    u.NOME,
                    m.COR,
                    COUNT(ia.ID_INSCRICAO_ALUNO) AS NUM_INSCRICOES
                FROM AULAS a
                INNER JOIN USUARIO u ON u.ID_USUARIO = a.ID_USUARIO
                INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
                LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
                WHERE {dia.upper()} = 1
                GROUP BY a.ID_AULA, m.DESCRICAO, HORA_AULA, HORA_TERMINO, LOTACAO, u.NOME, m.COR
                ''')
            dias[dia] = cursor.fetchall()
    except Exception as e:
        flash(("Houve um erro ao obter as aulas:", e), 'error')
    finally:
        cursor.close()

    aulasObtidas = []
    totalInscricoes = 0

    try:
        cursor = con.cursor()

        cursor.execute("SELECT * FROM AULAS ")
        aulas = cursor.fetchall()

        cursor.execute("SELECT COUNT(*) FROM AULAS")
        totalAulasCadastradas = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM INSCRICOES_ALUNO")
        totalInscricoes = cursor.fetchone()[0]

        cursor.close()
    except Exception as e:
        print(e)
        flash("Não foi possível obter as aulas", "error")

    return render_template('PaginaProfessorAulas.html',
                           aulas=dias,
                           aulasObtidas=aulas,
                           totalAulasCadastradas=totalAulasCadastradas,
                           totalInscricoes=totalInscricoes)

@app.route('/PaginaAlunoInscrições')
def pagina_aluno_inscricoes():
    if 'usuario' not in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 0 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Aluno", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()
    total_aulas = 0
    total_inscricoes = 0
    aulas = []

    try:
        # Total de aulas (geral)
        cursor.execute("SELECT COUNT(*) FROM AULAS")
        total_aulas = cursor.fetchone()[0]

        # Total de inscrições do aluno
        cursor.execute("SELECT COUNT(*) FROM INSCRICOES_ALUNO WHERE ID_USUARIO = ?", (session['usuario'][0],))
        total_inscricoes = cursor.fetchone()[0]

        # Aulas nas quais o aluno está inscrito
        cursor.execute('''
            SELECT
                a.ID_AULA AS ID,
                m.DESCRICAO,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                u.NOME,
                m.COR,
                COUNT(ia2.ID_INSCRICAO_ALUNO) AS NUM_INSCRICOES,
                a.DOMINGO, a.SEGUNDA, a.TERCA, a.QUARTA, a.QUINTA, a.SEXTA, a.SABADO
            FROM AULAS a
            INNER JOIN USUARIO u ON u.ID_USUARIO = a.ID_USUARIO
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            INNER JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            LEFT JOIN INSCRICOES_ALUNO ia2 ON a.ID_AULA = ia2.ID_AULA
            WHERE ia.ID_USUARIO = ?
            GROUP BY a.ID_AULA, m.DESCRICAO, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, u.NOME, m.COR,
                     a.DOMINGO, a.SEGUNDA, a.TERCA, a.QUARTA, a.QUINTA, a.SEXTA, a.SABADO
        ''', (session['usuario'][0],))

        aulas = cursor.fetchall()
        aulas_tratadas = []

        for aula in aulas:
            aula_list = list(aula)
            for n in range(8, 15):
                if aula[n] == 1:
                    dia_semana = {
                        8: 'Domingo',
                        9: 'Segunda-feira',
                        10: 'Terça-feira',
                        11: 'Quarta-feira',
                        12: 'Quinta-feira',
                        13: 'Sexta-feira',
                        14: 'Sábado'
                    }
                    aula_list.append(dia_semana[n])
                    break
            aulas_tratadas.append(tuple(aula_list))

        aulas = aulas_tratadas

    except Exception as e:
        flash("Não foi possível obter as inscrições", "error")
        print("Erro:", e)
    finally:
        cursor.close()

    return render_template(
        'PaginaAlunoInscrições.html',
        total_aulas=total_aulas,
        total_inscricoes=total_inscricoes,
        aulas=aulas
    )

@app.route('/PaginaAdminProfessores')
def pagina_admin_professores():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    professores = []
    cursor = con.cursor()

    try:
        cursor.execute('''SELECT ID_USUARIO
         , nome
         , email
         , telefone
         , senha
         , cpf
         , tipo
         , m.descricao 
         TENTATIVAS, 
         u.SITUACAO,
         m.COR
         FROM USUARIO u
         LEFT JOIN MODALIDADES m ON m.ID_MODALIDADE = u.ID_MODALIDADE
         WHERE u.TIPO = 2''')
        professores = cursor.fetchall()
        print(professores)
    except Exception as e:
        flash(f"Houve um erro ao obter os professores. {e}", 'error')
    finally:
        cursor.close()

    # Conta o total de aulas
    cursor.execute("SELECT COUNT(*) FROM AULAS")
    total_aulas = cursor.fetchone()[0]

    # Conta o total de inscritos
    cursor.execute("SELECT COUNT(*) FROM INSCRICOES_ALUNO")
    total_inscricoes = cursor.fetchone()[0]

    return render_template('PaginaAdminProfessores.html', professoresObtidos=professores, aulasObtidas=total_aulas, total_inscricoes=total_inscricoes)

@app.route('/cadastro')
def cadastro():
    return render_template('cadastro.html')

@app.route('/pagina-aluno')
def pagina_aluno():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 0 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Aluno", 'error')
        return redirect(url_for('login'))
    
    cursor = con.cursor()
    aulas = []
    total_aulas = 0
    total_inscricoes = 0

    try:
        usuario_id = session['usuario'][0]

        # Seleciona apenas aulas que o usuário ainda não está inscrito e que têm vagas disponíveis
        cursor.execute('''
        SELECT
            a.ID_AULA AS ID,
            m.DESCRICAO,
            a.HORA_AULA,
            a.HORA_TERMINO,
            a.LOTACAO,
            u.NOME,
            m.COR,
            COUNT(ia.ID_INSCRICAO_ALUNO) AS NUM_INSCRICOES,
            DOMINGO, SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO
        FROM AULAS a
        INNER JOIN USUARIO u ON u.ID_USUARIO = a.ID_USUARIO
        INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
        LEFT JOIN INSCRICOES_ALUNO ia ON a.ID_AULA = ia.ID_AULA
        WHERE a.ID_AULA NOT IN (
            SELECT ID_AULA FROM INSCRICOES_ALUNO WHERE ID_USUARIO = ?
        )
        GROUP BY a.ID_AULA, m.DESCRICAO, a.HORA_AULA, a.HORA_TERMINO,
                 a.LOTACAO, u.NOME, m.COR, a.DOMINGO, a.SEGUNDA,
                 a.TERCA, a.QUARTA, a.QUINTA, a.SEXTA, a.SABADO
        HAVING COUNT(ia.ID_INSCRICAO_ALUNO) < a.LOTACAO
        ''', (usuario_id,))
        
        aulas = cursor.fetchall()
        aulas_tratadas = []
        
        for aula in aulas:
            aula_list = list(aula)
            for n in range(8, 15):
                if aula[n] == 1:
                    dia_semana = {
                        8: 'Domingo',
                        9: 'Segunda-feira',
                        10: 'Terça-feira',
                        11: 'Quarta-feira',
                        12: 'Quinta-feira',
                        13: 'Sexta-feira',
                        14: 'Sábado'
                    }
                    aula_list.append(dia_semana[n])
                    break
            aulas_tratadas.append(tuple(aula_list))
        aulas = aulas_tratadas
        
        cursor.execute("SELECT COUNT(*) FROM AULAS")
        total_aulas = cursor.fetchone()[0] or 0

        # Total de aulas em que o usuário já está inscrito
        cursor.execute("SELECT COUNT(*) FROM INSCRICOES_ALUNO WHERE ID_USUARIO = ?", (usuario_id,))
        total_inscricoes = cursor.fetchone()[0]

    except Exception as e:
        flash("Houve um erro ao carregar as aulas.", "error")
    finally:
        cursor.close()

    return render_template('pagina-aluno.html', aulas=aulas, aulasObtidas=total_aulas, total_inscricoes=total_inscricoes)

@app.route('/edicao_aula_adm')
def edicao_aula_adm():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    return render_template('editaraula-admin.html')

@app.route('/editar-aula-admin/<int:id_aula>', methods=['GET', 'POST'])
def editar_aula_admin(id_aula):
    if 'usuario' not in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()

    if request.method == 'GET':
        aula = None
        modalidades = []
        professores = []
        try:
            cursor.execute("""
                SELECT ID_AULA, ID_MODALIDADE, DOMINGO, SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO,
                       HORA_AULA, HORA_TERMINO, LOTACAO, ID_USUARIO
                FROM AULAS WHERE ID_AULA = ?
            """, (id_aula,))
            aula = cursor.fetchone()

            cursor.execute("SELECT id_modalidade, descricao FROM MODALIDADES")
            modalidades = cursor.fetchall()

            cursor.execute("SELECT id_usuario, nome FROM USUARIO WHERE TIPO = 2")
            professores = cursor.fetchall()

        except Exception as e:
            flash(f"Houve um erro ao obter os dados da aula: {e}", 'error')
        finally:
            cursor.close()

        return render_template(
            'editaraula-admin.html',
            aula=aula,
            modalidadesObtidas=modalidades,
            professoresObtidos=professores
        )

    elif request.method == 'POST':
        try:
            # 🔹 Captura dos dados do formulário
            modalidade = request.form['modalidade']
            professor = request.form['professor']
            dia_da_aula = request.form['data-aula']  # vem em minúsculas (ex: 'segunda')
            horario = request.form['horario']
            horario_termino = request.form['horario_termino']
            vagas = request.form['vagas']

            # 🔹 Validação básica de horário
            if horario_termino <= horario:
                flash('O horário de término deve ser maior que o de início.', 'error')
                return redirect(url_for('criar_aula_admin'))

            # 🔹 Mapeia o valor recebido do HTML para a coluna do banco
            lista_dias = {
                'domingo': 'DOMINGO',
                'segunda': 'SEGUNDA',
                'terca': 'TERCA',
                'quarta': 'QUARTA',
                'quinta': 'QUINTA',
                'sexta': 'SEXTA',
                'sabado': 'SABADO'
            }

            dia_coluna = lista_dias.get(dia_da_aula)
            if not dia_coluna:
                flash("Dia inválido.", 'error')
                return redirect(url_for('criar_aula_admin'))

            # 🔹 Cria o dicionário de dias 0/1 para inserir
            dias = {
                'DOMINGO': 1 if dia_coluna == 'DOMINGO' else 0,
                'SEGUNDA': 1 if dia_coluna == 'SEGUNDA' else 0,
                'TERCA': 1 if dia_coluna == 'TERCA' else 0,
                'QUARTA': 1 if dia_coluna == 'QUARTA' else 0,
                'QUINTA': 1 if dia_coluna == 'QUINTA' else 0,
                'SEXTA': 1 if dia_coluna == 'SEXTA' else 0,
                'SABADO': 1 if dia_coluna == 'SABADO' else 0
            }

            # 🔹 Verifica conflito de horário e dia (mesmo professor)
            cursor.execute(f"""
                            SELECT 1
                            FROM AULAS
                            WHERE ID_USUARIO = ?
                              AND (
                                    (? = 1 AND SEGUNDA = 1) OR
                                    (? = 1 AND TERCA = 1) OR
                                    (? = 1 AND QUARTA = 1) OR
                                    (? = 1 AND QUINTA = 1) OR
                                    (? = 1 AND SEXTA = 1) OR
                                    (? = 1 AND SABADO = 1) OR
                                    (? = 1 AND DOMINGO = 1)
                                  )
                              AND (
                                    (? BETWEEN HORA_AULA AND HORA_TERMINO)
                                    OR (HORA_AULA BETWEEN ? AND ?)
                                    OR (? BETWEEN HORA_AULA AND HORA_TERMINO)
                                  )
                              AND NOT (ID_AULA = {id_aula})
                        """, (
                professor,
                dias['SEGUNDA'], dias['TERCA'], dias['QUARTA'], dias['QUINTA'],
                dias['SEXTA'], dias['SABADO'], dias['DOMINGO'],
                horario, horario, horario_termino, horario_termino
            ))

            conflito = cursor.fetchone()
            if conflito:
                flash('O professor já possui uma aula neste dia e horário.', 'error')
                return redirect(url_for('editar_aula_admin', id_aula=id_aula))

            # 🔹 Confere se modalidade e professor existem
            cursor.execute("SELECT id_modalidade FROM MODALIDADES WHERE id_modalidade = ?", (modalidade,))
            modalidade_id = cursor.fetchone()

            cursor.execute("SELECT id_usuario FROM USUARIO WHERE id_usuario = ?", (professor,))
            professor_id = cursor.fetchone()

            if not modalidade_id or not professor_id:
                flash("Modalidade ou professor não encontrados.", 'error')
                return redirect(url_for('criar_aula_admin', id_aula=id_aula))

            # 🔹 Inserir nova aula
            cursor.execute('''
                UPDATE AULAS
                SET
                    ID_MODALIDADE = ?,
                    DOMINGO = ?,
                    SEGUNDA = ?,
                    TERCA = ?,
                    QUARTA = ?,
                    QUINTA = ?,
                    SEXTA = ?,
                    SABADO = ?,
                    HORA_AULA = ?,
                    HORA_TERMINO = ?,
                    LOTACAO = ?,
                    ID_USUARIO = ?
                WHERE ID_AULA = ?;
                ''', (
                modalidade_id[0],
                dias['DOMINGO'], dias['SEGUNDA'], dias['TERCA'], dias['QUARTA'],
                dias['QUINTA'], dias['SEXTA'], dias['SABADO'],
                horario, horario_termino, vagas, professor_id[0], id_aula
            ))

            con.commit()
            flash("Aula atualizada com sucesso!", 'success')

        except Exception as e:
            con.rollback()
            flash(f"Houve um erro ao atualizar a aula: {e}", 'error')
            print("Erro ao atualizar aula:", e)
        finally:
            cursor.close()

        return redirect(url_for('editar_aula_admin', id_aula=id_aula))

@app.route('/criaraula_admin', methods=['GET', 'POST'])
def criar_aula_admin():
    if 'usuario' not in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()

    if request.method == "GET":
        modalidades = []
        professores = []
        try:
            cursor.execute("SELECT id_modalidade, descricao FROM MODALIDADES WHERE SITUACAO = 1")
            modalidades = cursor.fetchall()

            cursor.execute("SELECT id_usuario, nome FROM USUARIO WHERE TIPO = 2")
            professores = cursor.fetchall()
        except Exception as e:
            flash("Houve um erro ao obter os dados para criar a aula.", 'error')
            print("Erro ao buscar dados:", e)
        return render_template('criaraula-admin.html', professoresObtidos=professores, modalidadesObtidas=modalidades)

    elif request.method == "POST":
        try:
            # 🔹 Captura dos dados do formulário
            modalidade = request.form['modalidade']
            professor = request.form['professor']
            dia_da_aula = request.form['data-aula']  # vem em minúsculas (ex: 'segunda')
            horario = request.form['horario']
            horario_termino = request.form['horario_termino']
            vagas = request.form['vagas']

            # 🔹 Validação básica de horário
            if horario_termino <= horario:
                flash('O horário de término deve ser maior que o de início.', 'error')
                return redirect(url_for('criar_aula_admin'))

            # 🔹 Mapa o valor recebido do HTML para a coluna do banco
            lista_dias = {
                'domingo': 'DOMINGO',
                'segunda': 'SEGUNDA',
                'terca': 'TERCA',
                'quarta': 'QUARTA',
                'quinta': 'QUINTA',
                'sexta': 'SEXTA',
                'sabado': 'SABADO'
            }

            dia_coluna = lista_dias.get(dia_da_aula)
            if not dia_coluna:
                flash("Dia inválido.", 'error')
                return redirect(url_for('criar_aula_admin'))

            # 🔹 Cria o dicionário de dias 0/1 para inserir
            dias = {
                'DOMINGO': 1 if dia_coluna == 'DOMINGO' else 0,
                'SEGUNDA': 1 if dia_coluna == 'SEGUNDA' else 0,
                'TERCA': 1 if dia_coluna == 'TERCA' else 0,
                'QUARTA': 1 if dia_coluna == 'QUARTA' else 0,
                'QUINTA': 1 if dia_coluna == 'QUINTA' else 0,
                'SEXTA': 1 if dia_coluna == 'SEXTA' else 0,
                'SABADO': 1 if dia_coluna == 'SABADO' else 0
            }

            # 🔹 Verifica conflito de horário e dia (mesmo professor)
            cursor.execute("""
                SELECT 1
                FROM AULAS
                WHERE ID_USUARIO = ?
                  AND (
                        (? = 1 AND SEGUNDA = 1) OR
                        (? = 1 AND TERCA = 1) OR
                        (? = 1 AND QUARTA = 1) OR
                        (? = 1 AND QUINTA = 1) OR
                        (? = 1 AND SEXTA = 1) OR
                        (? = 1 AND SABADO = 1) OR
                        (? = 1 AND DOMINGO = 1)
                      )
                  AND (
                        (? BETWEEN HORA_AULA AND HORA_TERMINO)
                        OR (HORA_AULA BETWEEN ? AND ?)
                        OR (? BETWEEN HORA_AULA AND HORA_TERMINO)
                      )
            """, (
                professor,
                dias['SEGUNDA'], dias['TERCA'], dias['QUARTA'], dias['QUINTA'],
                dias['SEXTA'], dias['SABADO'], dias['DOMINGO'],
                horario, horario, horario_termino, horario_termino
            ))

            conflito = cursor.fetchone()
            if conflito:
                flash('O professor já possui uma aula neste dia e horário.', 'error')
                return redirect(url_for('criar_aula_admin'))

            # 🔹 Confere se modalidade e professor existem
            cursor.execute("SELECT id_modalidade FROM MODALIDADES WHERE id_modalidade = ?", (modalidade,))
            modalidade_id = cursor.fetchone()

            cursor.execute("SELECT id_usuario FROM USUARIO WHERE id_usuario = ?", (professor,))
            professor_id = cursor.fetchone()

            if not modalidade_id or not professor_id:
                flash("Modalidade ou professor não encontrados.", 'error')
                return redirect(url_for('criar_aula_admin'))

            # 🔹 Inserir nova aula
            cursor.execute('''
                INSERT INTO AULAS (
                    ID_MODALIDADE, DOMINGO, SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO,
                    HORA_AULA, HORA_TERMINO, LOTACAO, ID_USUARIO
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                modalidade_id[0],
                dias['DOMINGO'], dias['SEGUNDA'], dias['TERCA'], dias['QUARTA'],
                dias['QUINTA'], dias['SEXTA'], dias['SABADO'],
                horario, horario_termino, vagas, professor_id[0]
            ))

            con.commit()
            flash("Aula cadastrada com sucesso!", 'success')

        except Exception as e:
            con.rollback()
            flash("Houve um erro ao criar a aula. Tente novamente.", 'error')
            print("Erro ao criar aula:", e)
        finally:
            cursor.close()

        return redirect(url_for('pagina_admin_criando_aula'))


@app.route('/PaginaAdminRelatórios')
def pagina_admin_relatorios():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()

    # Conta o total de professores (TIPO = 2)
    cursor.execute("SELECT COUNT(*) FROM USUARIO WHERE TIPO = 2")
    total_professores = cursor.fetchone()[0]

    #Conta o total de aulas
    cursor.execute("SELECT COUNT(*) FROM AULAS")
    total_aulas = cursor.fetchone()[0]

    # Conta o total de inscritos
    cursor.execute("SELECT COUNT(*) FROM INSCRICOES_ALUNO")
    total_inscricoes = cursor.fetchone()[0]

    return render_template('PaginaAdminRelatorios.html', professoresObtidos=total_professores, aulasObtidas=total_aulas, total_inscricoes=total_inscricoes)

@app.route('/homecomusuario')
def home_com_usuario():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    return render_template('homecomusuario.html')

@app.route('/aulas-disponiveis-sem-usuario.html')
def aulas_disponiveis_sem_usuario():
    return render_template('aulas-disponiveis-sem-usuario.html')

@app.route('/editar-professor_admin/<int:id_usuario>', methods=['GET', 'POST'])
def editar_professor_admin(id_usuario):
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    if request.method == 'GET':
        cursor = con.cursor()
        cursor.execute("SELECT ID_USUARIO, NOME, EMAIL, SENHA, TELEFONE, CPF, ID_MODALIDADE FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
        professor = cursor.fetchone()

        cursor.execute("SELECT id_modalidade, descricao FROM MODALIDADES")
        modalidades = cursor.fetchall()

        return render_template('editar-professor_admin.html', professor=professor, modalidadesObtidas=modalidades)

    try:
        nome = request.form.get('nome')
        email = request.form.get('email')
        especialidade = request.form.get('especialidade')
        cpf = request.form.get('cpf')
        telefone = request.form.get('telefone')
        senha = request.form.get('senha')

        cursor = con.cursor()

        if senha:  # Só atualiza a senha se foi preenchida
            cursor.execute('''UPDATE USUARIO SET 
                NOME = ?,
                EMAIL = ?,
                ID_MODALIDADE = ?,
                CPF = ?,
                TELEFONE = ?,
                SENHA = ?
                WHERE ID_USUARIO = ?''',
                           (nome, email, especialidade, cpf, telefone, generate_password_hash(senha).decode('utf-8'),
                            id_usuario))
            con.commit()

        else:  # Senha não foi preenchida, então não atualiza esse campo
            cursor.execute('''UPDATE USUARIO SET 
                NOME = ?,
                EMAIL = ?,
                ID_MODALIDADE = ?,
                CPF = ?,
                TELEFONE = ?
                WHERE ID_USUARIO = ?''',
                           (nome, email, especialidade, cpf, telefone, id_usuario))

            con.commit()
        flash("Professor atualizado com sucesso.", 'success')
    except Exception as e:
        flash("Houve um erro ao atualizar o professor.", 'error')
    finally:
        cursor.close()

    return redirect(url_for('pagina_admin_professores'))


@app.route('/Cadastro-Professor.html')
def cadastro_professor():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()
    cursor.execute("SELECT id_modalidade, descricao FROM MODALIDADES")
    modalidades = cursor.fetchall()

    return render_template('Cadastro-Professor.html', modalidadesObtidas=modalidades)

@app.route('/criaraula-professor.html')
def criar_aula_professor():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'] == 0:
        flash("Acesso negado. Você não é um Professor", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()
    cursor.execute("SELECT id_modalidade, descricao FROM MODALIDADES")
    modalidades = cursor.fetchall()
    cursor.execute("SELECT id_usuario, NOME FROM USUARIO WHERE TIPO = 2")
    professores = cursor.fetchall()

    id_modalidade = request.form.get('especialidade')
    professor = request.form.get('professor')
    data_aula = request.form.get('data-aula')
    horario = request.form.get('horario')
    vagas = request.form.get('vagas')

    cursor.execute('''INSERT INTO AULAS (ID_MODALIDADE, ID_USUARIO, HORA_AULA, LOTACAO''')
    return render_template('PaginaProfessorAulas.html', modalidadesObtidas=modalidades, professoresObtidos=professores)

@app.route('/editaraula-professor.html')
def editar_aula_professor():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1:
        flash("Acesso negado. Você não é um Professor", 'error')
        return redirect(url_for('login'))

    # cursor = con.cursor()
    # cursor.execute("SELECT")

    return render_template('editaraula-professor.html')

@app.route('/PaginaProfessorRelatorios')
def pagina_professor_relatorios():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1:
        flash("Acesso negado. Você não é um Professor", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()
    cursor.execute("SELECT COUNT(*) FROM AULAS")
    total_aulas = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM INSCRICOES_ALUNO")
    total_inscricoes = cursor.fetchone()[0]
    cursor.close()

    return render_template('PaginaProfessorRelatorios.html', total_inscricoes=total_inscricoes, aulasObtidas=total_aulas)

@app.route('/editar-admin.html')
def editar_admin():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    return render_template('editar-admin.html')

@app.route('/cadastro_modalidade')
def cadastro_modalidade():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    return render_template('criar-modalidades.html')

@app.route('/pagina_admin_modalidades')
def pagina_admin_modalidades():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()

    # Conta o total de professores (TIPO = 2)
    cursor.execute("SELECT COUNT(*) FROM USUARIO WHERE TIPO = 2")
    total_professores = cursor.fetchone()[0]

    # Conta o total de inscritos
    cursor.execute("SELECT COUNT(*) FROM INSCRICOES_ALUNO")
    total_inscricoes = cursor.fetchone()[0]

    return render_template('PaginaAdminModalidades.html', professoresObtidos=total_professores, total_inscricoes=total_inscricoes)

@app.route('/excluiraula/<int:id_aula>')
def excluir_aula(id_aula):
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))
    cursor = con.cursor()
    try:
        cursor.execute("DELETE FROM AULAS WHERE ID_AULA = ?", (id_aula,))
        con.commit()
    except Exception as e:
        flash("Houve um erro ao excluir a aula.", 'error')
    finally:
        cursor.close()
        flash("Aula excluída com sucesso.", 'success')
        if session['usuario'][6] == 0:
            return redirect(url_for('pagina_admin_criando_aula'))
        else:
            return redirect(url_for('pagina_professor_aulas'))



@app.route('/criar_modalidade', methods=["POST"])
def criar_modalidade():

    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    descricao = request.form['nome-modalidade']
    situacao = request.form['situacao']
    cor = request.form['cor-modalidade']
    cursor = con.cursor()

    try:
        print(cor.replace('#', ''))

        cursor.execute('SELECT 1 FROM MODALIDADES WHERE DESCRICAO = ?', (descricao.upper(),))
        if cursor.fetchone():
            flash('Essa modalidade já está cadastrada.', "error")
            return redirect(url_for('cadastro_modalidade'))

        cursor.execute('''
            INSERT INTO MODALIDADES (DESCRICAO, SITUACAO, COR)
            VALUES (?, ?, ?)
        ''', (descricao.upper(), situacao, cor.replace('#', '')))

        con.commit()
        flash('Modalidade cadastrada com sucesso.', 'success')
    except Exception as e:
        flash(("Houve um erro ao cadastrar a modalidade.", str(e)), 'error')
        return redirect(url_for('cadastro_modalidade'))
    finally:
        cursor.close()

    return redirect(url_for('carregar_modalidades'))


@app.route('/criarusuario', methods=["POST"])
def criarusuario():
    nome = request.form['nome']
    email = request.form['email']
    senha = request.form['senha']
    telefone = request.form['telefone']
    confirmarSenha = request.form['confirmar-senha']
    cpf = request.form['CPF']
    cursor = con.cursor()

    if confirmarSenha != senha:
        flash("As senhas não coincidem", "error")
        return redirect(url_for('cadastro'))

    # Verificação de senha forte
    if not senha_forte(senha):
        flash('A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.', "error")
        return redirect(url_for('cadastro'))

    try:
        cursor.execute('SELECT 1 FROM USUARIO WHERE EMAIL = ?', (email,))
        if cursor.fetchone():
            flash('Esse usuário já está cadastrado.', "error")
            return redirect(url_for('cadastro'))

        senha_hash = generate_password_hash(senha).decode('utf-8')
        cursor.execute('''
            INSERT INTO USUARIO (NOME, EMAIL, SENHA, TELEFONE, CPF, TIPO, TENTATIVAS, SITUACAO)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (nome, email, senha_hash, telefone, cpf, 1, 0, 0))

        con.commit()
        flash('Usuário cadastrado com sucesso.', 'success')

    finally:
        cursor.close()

    return redirect(url_for('login'))

@app.route('/abrir_cadastro_admin')
def cadastro_admin():
    return render_template('cadastro-admin.html')

def senha_forte(senha):
    if len(senha) < 8:
        return False
    tem_maiuscula = any(c.isupper() for c in senha)
    tem_minuscula = any(c.islower() for c in senha)
    tem_numero = any(c.isdigit() for c in senha)
    tem_especial = any(not c.isalnum() for c in senha)
    return tem_maiuscula and tem_minuscula and tem_numero and tem_especial


@app.route('/criarusuario_admin', methods=["POST"])
def criarusuario_admin():
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    nome = request.form['nome']
    email = request.form['email']
    senha = request.form['senha']
    confirmarSenha = request.form['confirmar-senha']
    telefone = request.form['telefone']
    cpf = request.form['CPF']
    cursor = con.cursor()

    if confirmarSenha != senha:
        flash("As senhas não coincidem", "error")
        return redirect(url_for('criarusuario_admin'))

    # Verificação de senha forte
    senha_forte(senha)
    if not senha_forte(senha):
        flash(
            'A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.',
            "error")
        return redirect(url_for('cadastro_admin'))
    if not senha_forte(senha):
        flash('A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.',"error")
        return redirect(url_for('cadastro'))

    if not senha_forte(senha):
        flash('A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.', "error")
        return redirect(url_for('cadastro'))

    try:
        cursor.execute('SELECT 1 FROM USUARIO WHERE EMAIL = ?', (email,))
        if cursor.fetchone():
            flash('Esse usuário já está cadastrado.', "error")
            return redirect(url_for('cadastro'))

        senha_hash = generate_password_hash(senha).decode('utf-8')
        cursor.execute('''
            INSERT INTO USUARIO (NOME, EMAIL, SENHA, TELEFONE, CPF, TIPO, TENTATIVAS, SITUACAO)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (nome, email, senha_hash, telefone, cpf, 1, 0, 0))

        con.commit()
        flash('Usuário cadastrado com sucesso.', 'success')

    finally:
        cursor.close()

    return redirect(url_for('pagina_admin_usuarios'))

#Cadastro de professor (o admin cadastra o professor)
@app.route('/cadastro_professor', methods=["POST"])
def criar_professor():

    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    nome = request.form['nome']
    email = request.form['email']
    senha = request.form['senha']
    confirmarSenha = request.form['confirmar-senha']
    telefone = request.form['telefone']
    cpf = request.form['CPF']
    modalidade = request.form['especialidade']
    cursor = con.cursor()

    if confirmarSenha != senha:
        flash("As senhas não coincidem", "error")
        return redirect(url_for('cadastro_professor'))

    # Verificação de senha
    if not senha_forte(senha):
        flash('A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.', "error")
        return redirect(url_for('cadastro_professor'))
    try:
        cursor.execute('SELECT 1 FROM USUARIO WHERE EMAIL = ?', (email,))
        if cursor.fetchone():
            flash('Esse usuário já está cadastrado.', "error")
            return redirect(url_for('cadastro_professor'))

        senha_hash = generate_password_hash(senha).decode('utf-8')
        cursor.execute('''
            INSERT INTO USUARIO (NOME, EMAIL, SENHA, TELEFONE, CPF, TIPO, TENTATIVAS, SITUACAO, ID_MODALIDADE)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (nome, email, senha_hash, telefone, cpf, 2, 0, 0, modalidade))

        con.commit()
        flash('Professor cadastrado com sucesso.', 'success')

    finally:
        cursor.close()

    return redirect(url_for('pagina_admin_professores'))

# Edição de usuário
@app.route('/editarusuario/<int:id_usuario>', methods=['GET', 'POST'])
def editarusuario(id_usuario):
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    # Verifica se o usuário logado está tentando editar seu próprio perfil
    if session['usuario'][0] != id_usuario:
        flash("Você não tem permissão para editar este usuário.", 'error')
        # Redireciona para o perfil do usuário logado ou outra página segura
        return redirect(url_for('pagina_aluno'))

    cursor = con.cursor()
    # Pega os dados atuais do usuário (incluindo o caminho da imagem se houver)
    # Certifique-se de que a coluna IMAGEM exista e seja a última (índice 6) na tupla 'usuario' retornada
    cursor.execute("SELECT ID_USUARIO, NOME, EMAIL, SENHA, TELEFONE, CPF, IMAGEM FROM USUARIO WHERE ID_USUARIO = ?",
                   (id_usuario,))
    usuario = cursor.fetchone()
    cursor.close()

    if not usuario:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for('editaraluno'))  # Certifique-se de que 'editaraluno' é o nome correto da rota

    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']
        telefone = request.form['telefone']
        cpf = request.form['CPF']

        # 1. Lógica para o arquivo de imagem
        arquivo = request.files.get('imagem')  # Usa .get para evitar erro se o campo não estiver presente

        if arquivo and arquivo.filename != '':
            # Se um novo arquivo foi enviado, chame a função de upload.
            # Você precisa ajustar sua função 'upload_imagem' para receber o arquivo
            # ou incorporar sua lógica aqui.
            # Exemplo:
            # nome_imagem = salvar_imagem(arquivo, id_usuario)
            # Se 'upload_imagem' já faz tudo, chame-a, mas ela deve estar dentro do escopo.
            # Exemplo ajustado (depende de como 'upload_imagem' está definida):
            upload_imagem(id_usuario)  # Mantendo sua função original por enquanto, mas ela deve ser revisada

        # 2. Lógica da Senha
        hash_senha = usuario[3]  # Usa a senha existente por padrão (índice 3 da tupla usuario)

        if senha:
            # Validação de senha
            if not senha_forte(senha):
                flash(
                    'A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.',
                    "error")
                # Use a rota atual para permanecer na página de edição
                return redirect(url_for('editarusuario', id_usuario=id_usuario))

            from werkzeug.security import generate_password_hash
            hash_senha = generate_password_hash(senha).decode('utf-8')

        # 3. Atualização do Banco de Dados
        cursor = con.cursor()
        # **CORREÇÃO CRÍTICA:** Remova a vírgula extra antes do WHERE.
        # Se 'upload_imagem' atualiza a coluna IMAGEM no DB, esta query está ok.
        # Caso contrário, você deve incluir a atualização da coluna IMAGEM aqui.
        cursor.execute("UPDATE USUARIO SET NOME = ?, EMAIL = ?, SENHA = ?, TELEFONE = ?, CPF = ? WHERE ID_USUARIO = ?",
                       (nome, email, hash_senha, telefone, cpf, id_usuario))
        con.commit()
        # Não feche o cursor ainda, pois você vai usá-lo para a atualização da sessão

        # 4. Atualização da Sessão
        # Esta query DEVE retornar todas as colunas que você espera na sua session['usuario']
        # (ID_USUARIO, NOME, EMAIL, TELEFONE, SENHA, CPF, TIPO, TENTATIVAS, SITUACAO, IMAGEM)
        cursor.execute('''SELECT 
                            ID_USUARIO, NOME, EMAIL, TELEFONE, SENHA, CPF, 
                            TIPO, TENTATIVAS, SITUACAO, IMAGEM
                            FROM USUARIO WHERE ID_USUARIO = ?''',
                       (id_usuario,))  # Use ID para garantir que é o usuário correto

        session['usuario'] = cursor.fetchone()  # Atualiza a sessão com os novos dados
        cursor.close()

        flash("Usuário atualizado com sucesso.", 'success')
        if session['usuario'][6] == 2:  # TIPO está no índice 6
            return redirect(url_for('pagina_professor_aulas'))
        else:
            return redirect(url_for('pagina_aluno'))

    return render_template('editar-aluno.html', usuario=usuario, titulo='Editar Usuário')

    # Login de usuário

# Edição de usuário-admin
@app.route('/editarusuario_admin/<int:id_usuario>', methods=['GET', 'POST'])
def editarusuario_admin(id_usuario):

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()
    cursor.execute("SELECT ID_USUARIO, NOME, EMAIL, SENHA, TELEFONE, CPF FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
    usuario = cursor.fetchone()
    cursor.close()

    if not usuario:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for('editaraluno'))

    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']
        telefone = request.form['telefone']
        cpf = request.form['CPF']



        if senha:
            senha_forte(senha)
            if not senha_forte(senha):
                flash(
                    'A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.',
                    "error")
                return redirect(url_for('editarusuario_admin', id_usuario=id_usuario))
            hash_senha = generate_password_hash(senha).decode('utf-8')

        else:
            hash_senha = usuario[3]


        cursor = con.cursor()
        cursor.execute("UPDATE USUARIO SET NOME = ?, EMAIL = ?, SENHA = ?, TELEFONE = ?, CPF = ? WHERE ID_USUARIO = ?",
                       (nome, email, hash_senha, telefone, cpf, id_usuario))
        con.commit()
        cursor.close()

        # atualiza
        cursor.execute('''SELECT
                            ID_USUARIO, 
                            NOME,
                            EMAIL,
                            TELEFONE, 
                            SENHA, 
                            CPF, 
                            TIPO,
                            TENTATIVAS,
                            SITUACAO,
                            IMAGEM
         FROM USUARIO WHERE EMAIL = ?''', (email,))

        usuario = cursor.fetchone() # Atualiza a sessão com os novos dados

        if usuario[0] == session['usuario'][0]:
            session['usuario'] = usuario

        # print(session['usuario'])

        flash("Usuário atualizado com sucesso.", 'success')
        return redirect(url_for('pagina_admin_usuarios'))

    return render_template('editar-aluno-admin.html', usuario=usuario, titulo='Editar Usuário')



@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        cursor = con.cursor()

        try:
            # Busca apenas pela senha criptografada com base no e-mail
            cursor.execute('''SELECT 
                            ID_USUARIO, 
                            NOME,
                            EMAIL,
                            TELEFONE, 
                            SENHA, 
                            CPF, 
                            TIPO,
                            TENTATIVAS,
                            SITUACAO,
                            IMAGEM
             FROM USUARIO WHERE EMAIL = ?''', (email,))
            usuario = cursor.fetchone()

            if not usuario:
                flash('Usuário não encontrado.', "error")
                return redirect(url_for('login'))

            if usuario[8] == 1:
                flash('Usuario esta bloqueado', "error")
                return redirect(url_for('login'))

            senha_armazenada = usuario[4]  # A senha criptografada no banco

            if check_password_hash(senha_armazenada, senha):
                session['usuario'] = usuario  # Armazena o e-mail na sessão
                cursor.execute('UPDATE USUARIO SET TENTATIVAS = 0 WHERE ID_USUARIO = ?', (usuario[0],))
                con.commit()
                flash('Login realizado com sucesso.', "success")

                if usuario[6] == 0:
                    return redirect(url_for('pagina_admin_usuarios'))
                elif usuario[6] == 2:
                    return redirect(url_for('pagina_professor_aulas'))
                else:
                    return redirect(url_for('pagina_aluno_inscricoes'))

            else:
                cursor.execute('''UPDATE USUARIO SET TENTATIVAS = TENTATIVAS + 1 WHERE ID_USUARIO = ?''', (usuario[0],))
                con.commit()

                tentativas = usuario[7]
                if tentativas >= 2:
                    cursor.execute('UPDATE USUARIO SET SITUACAO = 1 WHERE ID_USUARIO = ?', (usuario[0],))
                    con.commit()
                    flash('Conta bloqueada devido a múltiplas tentativas de login falhadas.', "error")
                    return redirect(url_for('login'))

                else:
                    flash('Você tem {} tentativas restantes.'.format(2 - tentativas), "error")

                flash('Senha incorreta.', "error")
                return redirect(url_for('login'))



        finally:
            cursor.close()

    return render_template('login.html')

@app.route('/logout')
def logout():
    if 'usuario' in session:
        session.pop('usuario', None)
    flash('Você saiu da sua conta.', 'success')
    return redirect(url_for('index'))

@app.route('/pagina_admin_usuarios')
def pagina_admin_usuarios():

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    usuariosObtidos = []

    try:
        cursor = con.cursor()
        cursor.execute("SELECT * FROM USUARIO")
        usuariosObtidos = cursor.fetchall()
        cursor.close()
    except Exception as e:
        flash("Houve um erro ao obter usuários.", 'error')

    cursor = con.cursor()

    # Conta o total de professores (TIPO = 2)
    cursor.execute("SELECT COUNT(*) FROM USUARIO WHERE TIPO = 2")
    total_professores = cursor.fetchone()[0]

    # Conta o total de aulas
    cursor.execute("SELECT COUNT(*) FROM AULAS")
    total_aulas = cursor.fetchone()[0]

    # Conta o total de inscritos
    cursor.execute("SELECT COUNT(*) FROM INSCRICOES_ALUNO")
    total_inscricoes = cursor.fetchone()[0]

    return render_template('PaginaAdminUsuarios.html', usuariosObtidos=usuariosObtidos, professoresObtidos=total_professores, aulasObtidas=total_aulas, total_inscricoes=total_inscricoes)

@app.route('/carregar_modalidades')
def carregar_modalidades():
    modalidades = []
    try:
        cursor = con.cursor()
        cursor.execute("SELECT * FROM MODALIDADES")
        modalidades = cursor.fetchall()
        cursor.close()
    except Exception as e:
        flash("Houve um erro ao obter as modalidades.", 'error')

    cursor = con.cursor()

    # Conta o total de professores (TIPO = 2)
    cursor.execute("SELECT COUNT(*) FROM USUARIO WHERE TIPO = 2")
    total_professores = cursor.fetchone()[0]

    # Conta o total de aulas
    cursor.execute("SELECT COUNT(*) FROM AULAS")
    total_aulas = cursor.fetchone()[0]

    # Conta o total de inscritos
    cursor.execute("SELECT COUNT(*) FROM INSCRICOES_ALUNO")
    total_inscricoes = cursor.fetchone()[0]

    return render_template('PaginaAdminModalidades.html', modalidadesObtidas=modalidades, professoresObtidos=total_professores, aulasObtidas=total_aulas, total_inscricoes=total_inscricoes)

@app.route('/excluirmodalidade/<int:id_modalidade>')
def excluir_modalidade(id_modalidade):

    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()
    try:
        cursor.execute("DELETE FROM MODALIDADES WHERE ID_MODALIDADE = ?", (id_modalidade,))
        con.commit()
        flash("Modalidade excluída com sucesso.", 'success')
    except Exception as e:
        flash("A modalidade está vinculada à uma aula ou professor.", 'error')
    finally:
        cursor.close()
    return redirect(url_for('carregar_modalidades'))

@app.route('/editar_modalidade/<int:id_modalidade>', methods=['GET', 'POST'])
def editar_modalidade(id_modalidade):
    if session['usuario'][6] == 1 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Admin", 'error')
        return redirect(url_for('login'))

    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()

    if request.method == 'GET':
        cursor.execute("""
            SELECT ID_MODALIDADE, DESCRICAO, SITUACAO, COR
            FROM MODALIDADES
            WHERE ID_MODALIDADE = ?
        """, (id_modalidade,))
        modalidade = cursor.fetchone()

        cursor.close()

        if not modalidade:
            flash("Modalidade não encontrada.", "error")
            return redirect(url_for('carregar_modalidades'))

        # situacao é o terceiro campo retornado
        situacao = modalidade[2]

        return render_template(
            'editar_modalidade.html',
            modalidade=modalidade,
            situacao=situacao,
            titulo='Editar Modalidade'
        )

    # Método POST
    nomeModalidade = request.form['nome-modalidade']
    situacao = request.form['situacao']
    cor = request.form['cor-modalidade']

    cursor.execute("""
        UPDATE MODALIDADES
        SET DESCRICAO = ?, SITUACAO = ?, COR = ?
        WHERE ID_MODALIDADE = ?
    """, (nomeModalidade, situacao, cor.replace('#', ''), id_modalidade))

    con.commit()  # Importante: salvar as alterações no banco
    cursor.close()

    flash("Modalidade atualizada com sucesso!", "success")
    return redirect(url_for('carregar_modalidades'))


@app.route('/excluiraluno/<int:id_usuario>')
def excluir_aluno(id_usuario):
    print(id_usuario)

    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if not session['usuario'][6] == 0:  # Verifica se o usuário é admin
        flash("Acesso negado. Apenas administradores podem excluir usuários.", 'error')
        return redirect(url_for('pagina_admin_usuarios'))

    try:
        cursor = con.cursor()
        cursor.execute("DELETE FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
        con.commit()
        cursor.close()
        flash("Usuário excluído com sucesso", 'success')
    except Exception as e:
        flash("Houve um erro ao excluir o usuário.", 'error')
    return redirect(url_for('pagina_admin_usuarios'))

@app.route('/excluir_professor/<int:id_usuario>')
def excluir_professor(id_usuario):

    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if not session['usuario'][6] == 0:  # Verifica se o usuário é admin
        flash("Acesso negado. Apenas administradores podem excluir professores.", 'error')
        return redirect(url_for('pagina_admin_professores'))

    try:
        cursor = con.cursor()
        cursor.execute("DELETE FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
        con.commit()
        cursor.close()
        flash("Excluído com sucesso ", 'success')
    except Exception as e:
        flash("Houve um erro ao excluir o usuário.", 'error')
    return redirect(url_for('pagina_admin_professores'))

@app.route('/aluno/inscrever/<int:id_aula>', methods=['GET'])
def inscrever(id_aula):
    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    if session['usuario'][6] == 0 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Aluno", 'error')
        return redirect(url_for('login'))
    
    cursor = con.cursor()
    try:
        # Primeiro, obter informações da aula que o aluno quer se inscrever
        cursor.execute("""
            SELECT HORA_AULA, HORA_TERMINO, DOMINGO, SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO
            FROM AULAS 
            WHERE ID_AULA = ?
        """, (id_aula,))
        nova_aula = cursor.fetchone()
        
        if not nova_aula:
            flash("Aula não encontrada.", "error")
            return redirect(url_for('pagina_aluno'))
        
        # Verificar conflitos com aulas existentes
        cursor.execute("""
            SELECT a.HORA_AULA, a.HORA_TERMINO, a.DOMINGO, a.SEGUNDA, a.TERCA, a.QUARTA, a.QUINTA, a.SEXTA, a.SABADO
            FROM AULAS a
            INNER JOIN INSCRICOES_ALUNO ia ON a.ID_AULA = ia.ID_AULA
            WHERE ia.ID_USUARIO = ?
        """, (session['usuario'][0],))
        
        aulas_existentes = cursor.fetchall()
        
        # Verificar conflitos de horário
        for aula in aulas_existentes:
            # Verificar se há sobreposição de dias
            for i in range(2, 9):  # índices dos dias da semana
                if nova_aula[i] and aula[i]:  # se ambas as aulas acontecem no mesmo dia
                    # Verificar se há sobreposição de horários
                    if (nova_aula[0] <= aula[1] and nova_aula[1] >= aula[0]):
                        flash("Você já está inscrito em uma aula neste horário.", "error")
                        return redirect(url_for('pagina_aluno'))
        
        # Se não houver conflitos, fazer a inscrição
        cursor.execute("""
            INSERT INTO INSCRICOES_ALUNO (ID_USUARIO, ID_AULA)
            VALUES (?, ?)
        """, (session['usuario'][0], id_aula))
        
        con.commit()
        flash("Inscrição realizada com sucesso!", "success")
        
    except Exception as e:
        flash(f"Erro ao realizar inscrição: {str(e)}", "error")
        con.rollback()
    finally:
        cursor.close()
    
    return redirect(request.referrer or url_for('pagina_aluno'))

@app.route('/aluno/desinscrever/<int:id_aula>', methods=['GET'])
def cancelar_inscricao(id_aula):
    if session['usuario'][6] == 0 or session['usuario'][6] == 2:
        flash("Acesso negado. Você não é um Aluno", 'error')
        return redirect(url_for('login'))

    if not 'usuario' in session:
        flash("Acesso negado. Por favor, faça login.", 'error')
        return redirect(url_for('login'))

    cursor = con.cursor()
    try:
        cursor.execute("""
        DELETE FROM INSCRICOES_ALUNO
        WHERE ID_AULA = ? AND ID_USUARIO = ?
        """, (id_aula, session['usuario'][0]))

        con.commit()
    except Exception as e:
        con.rollback()
    finally:
        cursor.close()
    return redirect(request.referrer or url_for('pagina-aluno'))

@app.route('/upload_imagem/<int:id_usuario>', methods=['POST'])
def upload_imagem(id_usuario):
    arquivo = request.files['imagem']

    if arquivo:


        caminho = 'static/uploads/' + arquivo.filename
        arquivo.save(caminho)

        con = fdb.connect(
            database = r'C:\Users\Aluno\Desktop\SPARTA.FDB',
            user = 'sysdba',
            password = 'sysdba'
        )
        cur = con.cursor()
        cur.execute("UPDATE usuario SET imagem = ? WHERE id_usuario = ?", (arquivo.filename, id_usuario))
        con.commit()
        con.close()

        flash('Imagem enviada com sucesso', 'success')

    return redirect(url_for('pagina_admin_usuarios'))

@app.route('/aulas/relatorio_lotado', methods=['GET'])
def gerar_relatorio_lotado():
    cursor = con.cursor()
    cursor.execute("""
        SELECT * FROM (
            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'DOMINGO' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.DOMINGO = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) = a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'SEGUNDA' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.SEGUNDA = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) = a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'TERÇA' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.TERCA = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) = a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'QUARTA' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.QUARTA = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) = a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'QUINTA' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.QUINTA = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) = a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'SEXTA' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.SEXTA = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) = a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'SÁBADO' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.SABADO = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) = a.LOTACAO
        )
        ORDER BY
            CASE DIA
                WHEN 'DOMINGO' THEN 1
                WHEN 'SEGUNDA' THEN 2
                WHEN 'TERÇA' THEN 3
                WHEN 'QUARTA' THEN 4
                WHEN 'QUINTA' THEN 5
                WHEN 'SEXTA' THEN 6
                WHEN 'SÁBADO' THEN 7
            END,
            HORA_AULA;
    """)
    aulas = cursor.fetchall()
    cursor.close()

    # --- Criação do PDF ---
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Cabeçalho
    pdf.set_font("Arial", style='B', size=18)
    pdf.cell(190, 10, "Relatório de Aulas Lotadas - Todos os Dias", ln=True, align='C')
    pdf.ln(5)
    pdf.set_draw_color(0, 0, 0)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(10)

    # Cabeçalho da tabela
    pdf.set_font("Arial", style='B', size=12)
    pdf.set_fill_color(230, 230, 230)
    pdf.cell(15, 10, "ID", 1, 0, 'C', True)
    pdf.cell(25, 10, "Início", 1, 0, 'C', True)
    pdf.cell(25, 10, "Término", 1, 0, 'C', True)
    pdf.cell(25, 10, "Lotação", 1, 0, 'C', True)
    pdf.cell(55, 10, "Modalidade", 1, 0, 'C', True)
    pdf.cell(25, 10, "Alunos", 1, 0, 'C', True)
    pdf.cell(25, 10, "Dia", 1, 1, 'C', True)

    # Linhas da tabela
    pdf.set_font("Arial", size=11)
    fill = False
    for aula in aulas:
        pdf.set_fill_color(245, 245, 245) if fill else pdf.set_fill_color(255, 255, 255)
        pdf.cell(15, 10, str(aula[0]), 1, 0, 'C', fill)
        pdf.cell(25, 10, str(aula[1]), 1, 0, 'C', fill)
        pdf.cell(25, 10, str(aula[2]), 1, 0, 'C', fill)
        pdf.cell(25, 10, str(aula[3]), 1, 0, 'C', fill)
        pdf.cell(55, 10, str(aula[4]), 1, 0, 'L', fill)
        pdf.cell(25, 10, str(aula[6]), 1, 0, 'C', fill)
        pdf.cell(25, 10, str(aula[5]), 1, 1, 'C', fill)
        fill = not fill

    # Totalizador
    contador_aulas = len(aulas)
    pdf.ln(10)
    pdf.set_font("Arial", style='B', size=12)
    pdf.cell(190, 10, f"Total de aulas lotadas: {contador_aulas}", ln=True, align='R')

    # Rodapé com data/hora
    pdf.set_y(-20)
    pdf.set_font("Arial", size=9)
    data_atual = datetime.now().strftime("%d/%m/%Y %H:%M")
    pdf.cell(0, 10, f"Gerado automaticamente pelo sistema - {data_atual}", 0, 0, 'C')

    # Salvar e retornar o PDF
    pdf_path = "relatorio_aulas_lotadas.pdf"
    pdf.output(pdf_path)
    return send_file(pdf_path, as_attachment=True, mimetype='application/pdf')

@app.route('/aulas/relatorio_liberada', methods=['GET'])
def gerar_relatorio_liberadas():
    cursor = con.cursor()
    cursor.execute("""
        SELECT * FROM (
            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'DOMINGO' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS,
                (a.LOTACAO - COUNT(ia.ID_USUARIO)) AS VAGAS_RESTANTES
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.DOMINGO = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) < a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'SEGUNDA' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS,
                (a.LOTACAO - COUNT(ia.ID_USUARIO)) AS VAGAS_RESTANTES
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.SEGUNDA = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) < a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'TERÇA' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS,
                (a.LOTACAO - COUNT(ia.ID_USUARIO)) AS VAGAS_RESTANTES
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.TERCA = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) < a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'QUARTA' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS,
                (a.LOTACAO - COUNT(ia.ID_USUARIO)) AS VAGAS_RESTANTES
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.QUARTA = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) < a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'QUINTA' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS,
                (a.LOTACAO - COUNT(ia.ID_USUARIO)) AS VAGAS_RESTANTES
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.QUINTA = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) < a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'SEXTA' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS,
                (a.LOTACAO - COUNT(ia.ID_USUARIO)) AS VAGAS_RESTANTES
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.SEXTA = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) < a.LOTACAO

            UNION ALL

            SELECT 
                a.ID_AULA,
                a.HORA_AULA,
                a.HORA_TERMINO,
                a.LOTACAO,
                m.DESCRICAO,
                'SÁBADO' AS DIA,
                COUNT(ia.ID_USUARIO) AS QTD_ALUNOS,
                (a.LOTACAO - COUNT(ia.ID_USUARIO)) AS VAGAS_RESTANTES
            FROM AULAS a
            INNER JOIN MODALIDADES m ON m.ID_MODALIDADE = a.ID_MODALIDADE
            LEFT JOIN INSCRICOES_ALUNO ia ON ia.ID_AULA = a.ID_AULA
            WHERE a.SABADO = 1
            GROUP BY a.ID_AULA, a.HORA_AULA, a.HORA_TERMINO, a.LOTACAO, m.DESCRICAO
            HAVING COUNT(ia.ID_USUARIO) < a.LOTACAO
        )
        ORDER BY
            CASE DIA
                WHEN 'DOMINGO' THEN 1
                WHEN 'SEGUNDA' THEN 2
                WHEN 'TERÇA' THEN 3
                WHEN 'QUARTA' THEN 4
                WHEN 'QUINTA' THEN 5
                WHEN 'SEXTA' THEN 6
                WHEN 'SÁBADO' THEN 7
            END,
            HORA_AULA;
    """)
    aulas = cursor.fetchall()
    cursor.close()



    # --- Criação do PDF ---
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    pdf.set_font("Arial", style='B', size=18)
    pdf.cell(190, 10, "Relatório de Aulas com Vagas por Dia da Semana", ln=True, align='C')
    pdf.ln(5)
    pdf.set_draw_color(0, 0, 0)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(10)

    # Cabeçalho da tabela
    pdf.set_font("Arial", style='B', size=12)
    pdf.set_fill_color(230, 230, 230)
    pdf.cell(15, 10, "ID", 1, 0, 'C', True)
    pdf.cell(25, 10, "Início", 1, 0, 'C', True)
    pdf.cell(25, 10, "Término", 1, 0, 'C', True)
    pdf.cell(20, 10, "Lotação", 1, 0, 'C', True)
    pdf.cell(40, 10, "Modalidade", 1, 0, 'C', True)
    pdf.cell(20, 10, "Alunos", 1, 0, 'C', True)
    pdf.cell(20, 10, "Vagas", 1, 0, 'C', True)
    pdf.cell(25, 10, "Dia", 1, 1, 'C', True)

    # Linhas da tabela
    pdf.set_font("Arial", size=11)
    fill = False
    for aula in aulas:
        pdf.set_fill_color(245, 245, 245) if fill else pdf.set_fill_color(255, 255, 255)
        pdf.cell(15, 10, str(aula[0]), 1, 0, 'C', fill)
        pdf.cell(25, 10, str(aula[1]), 1, 0, 'C', fill)
        pdf.cell(25, 10, str(aula[2]), 1, 0, 'C', fill)
        pdf.cell(20, 10, str(aula[3]), 1, 0, 'C', fill)
        pdf.cell(40, 10, str(aula[4]), 1, 0, 'L', fill)
        pdf.cell(20, 10, str(aula[6]), 1, 0, 'C', fill)
        pdf.cell(20, 10, str(aula[7]), 1, 0, 'C', fill)
        pdf.cell(25, 10, str(aula[5]), 1, 1, 'C', fill)
        fill = not fill

    # Totalizador
    contador_aulas = len(aulas)
    pdf.ln(10)
    pdf.set_font("Arial", style='B', size=12)
    pdf.cell(190, 10, f"Total de aulas com vagas: {contador_aulas}", ln=True, align='R')

    # Rodapé com data/hora
    pdf.set_y(-20)
    pdf.set_font("Arial", size=9)
    data_atual = datetime.now().strftime("%d/%m/%Y %H:%M")
    pdf.cell(0, 10, f"Gerado automaticamente pelo sistema - {data_atual}", 0, 0, 'C')

    pdf_path = "relatorio_aulas_vagas.pdf"
    pdf.output(pdf_path)
    return send_file(pdf_path, as_attachment=True, mimetype='application/pdf')



if __name__ == "__main__":
    app.run(debug=True)