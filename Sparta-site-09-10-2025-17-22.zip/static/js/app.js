document.getElementById('abrir-menu').onclick = function() {
    document.getElementById('menu-js').style.display = 'block';
};
document.getElementById('fechar-menu').onclick = function() {
    document.getElementById('menu-js').style.display = 'none';
};

