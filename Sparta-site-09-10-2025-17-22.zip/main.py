from flask import Flask, render_template, session, url_for, redirect, flash, url_for, request
import fdb
from flask_bcrypt import generate_password_hash, check_password_hash


app = Flask(__name__)
app.secret_key = 'sparta'

# Configurações do banco de dados
host = 'localhost'
database = r'C:\Users\Aluno\Desktop\BANCO\SPARTA.FDB'
user = 'sysdba'
password = 'sysdba'

con = fdb.connect(host=host, database=database, user=user, password=password)

@app.route('/')
def index():
    return render_template('homesemusuario.html')

@app.route('/aulas_disponiveis')
def aulas_disponiveis():
    return render_template('aulas-disponiveis.html')

@app.route('/abrir_login')
def abrir_login():
    return render_template('login.html')

@app.route('/editaraluno')
def editaraluno():
    return render_template('editar-aluno.html')

@app.route('/homesemusuario')
def homesemusuario():
    return render_template('homesemusuario.html')

@app.route('/PaginaAdminCriandoaula')
def pagina_admin_criando_aula():
    return render_template('PaginaAdminCriandoaula.html')

@app.route('/PaginaProfessorAulas')
def pagina_professor_aulas():
    return render_template('PaginaProfessorAulas.html')

@app.route('/PaginaAlunoInscrições.html')
def pagina_aluno_inscricoes():
    return render_template('PaginaAlunoInscrições.html')

@app.route('/PaginaAdminProfessores')
def pagina_admin_professores():
    return render_template('PaginaAdminProfessores.html')

@app.route('/cadastro.html')
def cadastro():
    return render_template('cadastro.html')

@app.route('/pagina-aluno.html')
def pagina_aluno():
    return render_template('pagina-aluno.html')

@app.route('/editar-aula-admin.html')
def editar_aula_admin():
    return render_template('editar-aula-admin.html')

@app.route('/criaraula_admin.html')
def criar_aula_admin():
    return render_template('criaraula_admin.html')

@app.route('/PaginaAdminRelatórios')
def pagina_admin_relatorios():
    return render_template('PaginaAdminRelatórios.html')

@app.route('/homecomusuario.html')
def home_com_usuario():
    return render_template('homecomusuario.html')

@app.route('/editar-professor_admin.html')
def editar_professor_admin():
    return render_template('editar-professor_admin.html')

@app.route('/Cadastro-Professor.html')
def cadastro_professor():
    return render_template('Cadastro-Professor.html')

@app.route('/criaraula-professor.html')
def criar_aula_professor():
    return render_template('criaraula-professor.html')

@app.route('/editaraula-professor.html')
def editar_aula_professor():
    return render_template('editaraula-professor.html')

@app.route('/PaginaProfessorRelatorios.html')
def pagina_professor_relatorios():
    return render_template('PaginaProfessorRelatorios.html')

@app.route('/editar-admin.html')
def editar_admin():
    return render_template('editar-admin.html')

@app.route('/criarusuario', methods=["POST"])
def criarusuario():
    nome = request.form['nome']
    email = request.form['email']
    senha = request.form['senha']
    telefone = request.form['telefone']
    cpf = request.form['CPF']
    print('entrei')



    cursor = con.cursor()

    try:
        cursor.execute('SELECT 1 FROM USUARIOS WHERE EMAIL = ?', (email,))
        if cursor.fetchone():
            flash('Esse usuário já está cadastrado.')
            return redirect(url_for('cadastro'))
        senha_hash = generate_password_hash(senha).decode('utf-8')
        cursor.execute('INSERT INTO USUARIOS (NOME, EMAIL, SENHA, TELEFONE, CPF ) VALUES (?, ?, ?, ?, ?)',
                       (nome, email, senha_hash, telefone, cpf))
        con.commit()
        flash('Usuário cadastrado com sucesso.')
    finally:
        cursor.close()

    return redirect(url_for('cadastro'))

# Edição de usuário
@app.route('/editarusuario/<int:id>', methods=['GET', 'POST'])
def editarusuario(id_usuario):
    cursor = con.cursor()
    cursor.execute("SELECT ID_USUARIO, NOME, EMAIL, SENHA, TELEFONE, CPF FROM USUARIOS WHERE ID_USUARIO = ?", (id_usuario,))
    usuario = cursor.fetchone()
    cursor.close()

    if not usuario:
        flash("Usuário não encontrado.")
        return redirect(url_for('usuarios'))

    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']
        telefone = request.form['telefone']
        cpf = request.form['CPF']

        cursor = con.cursor()
        cursor.execute("UPDATE USUARIOS SET NOME = ?, EMAIL = ?, SENHA = ?, TELEFONE = ?, CPF = ? WHERE ID_USUARIO = ?",
                       (nome, email, senha, telefone, cpf, id_usuario))
        con.commit()
        cursor.close()
        flash("Usuário atualizado com sucesso.")
        return redirect(url_for('pagina_aluno'))

    return render_template('editar-aluno.html', usuario=usuario, titulo='Editar Usuário')

    # Login de usuário


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        cursor = con.cursor()

        try:
            # Busca apenas pela senha criptografada com base no e-mail
            cursor.execute('SELECT senha FROM USUARIOS WHERE EMAIL = ?', (email,))
            usuario = cursor.fetchone()

            if not usuario:
                flash('Usuário não encontrado.')
                return redirect(url_for('login'))

            senha_armazenada = usuario[0]  # A senha criptografada no banco

            if check_password_hash(senha_armazenada, senha):
                flash('Login realizado com sucesso.')
                return redirect(url_for('home_com_usuario'))
            else:
                flash('Senha incorreta.')
                return redirect(url_for('login'))

        finally:
            cursor.close()

    return render_template('login.html')





if __name__ == "__main__":
    app.run(debug=True)