from flask import Flask, render_template, session, url_for, redirect, flash, url_for, request
import fdb
from flask_bcrypt import generate_password_hash, check_password_hash


app = Flask(__name__)
app.secret_key = 'sparta'

# Configurações do banco de dados
host = 'localhost'
database = r'C:\Users\Aluno\Desktop\BANCO\SPARTA.FDB'
user = 'sysdba'
password = 'sysdba'

con = fdb.connect(host=host, database=database, user=user, password=password)

@app.route('/')
def index():
    return render_template('homesemusuario.html')

@app.route('/aulas_disponiveis')
def aulas_disponiveis():
    return render_template('aulas-disponiveis.html')

@app.route('/abrir_login')
def abrir_login():
    return render_template('login.html')

@app.route('/editaraluno')
def editaraluno():
    return render_template('editar-aluno.html')

@app.route('/homesemusuario')
def homesemusuario():
    return render_template('homesemusuario.html')

@app.route('/PaginaAdminCriandoaula')
def pagina_admin_criando_aula():
    return render_template('PaginaAdminCriandoaula.html')

@app.route('/PaginaProfessorAulas')
def pagina_professor_aulas():
    return render_template('PaginaProfessorAulas.html')

@app.route('/PaginaAlunoInscrições')
def pagina_aluno_inscricoes():
    return render_template('PaginaAlunoInscrições.html')

@app.route('/PaginaAdminProfessores')
def pagina_admin_professores():
    return render_template('PaginaAdminProfessores.html')

@app.route('/cadastro')
def cadastro():
    return render_template('cadastro.html')

@app.route('/pagina-aluno')
def pagina_aluno():
    return render_template('pagina-aluno.html')

@app.route('/editar-aula-admin')
def editar_aula_admin():
    return render_template('editar-aula-admin.html')

@app.route('/criaraula_admin')
def criar_aula_admin():
    return render_template('criaraula-admin.html')

@app.route('/PaginaAdminRelatórios')
def pagina_admin_relatorios():
    return render_template('PaginaAdminRelatorios.html')

@app.route('/homecomusuario.html')
def home_com_usuario():
    return render_template('homecomusuario.html')

@app.route('/aulas-disponiveis-sem-usuario.html')
def aulas_disponiveis_sem_usuario():
    return render_template('aulas-disponiveis-sem-usuario.html')

@app.route('/editar-professor_admin.html')
def editar_professor_admin():
    return render_template('editar-professor_admin.html')

@app.route('/Cadastro-Professor.html')
def cadastro_professor():
    return render_template('Cadastro-Professor.html')

@app.route('/criaraula-professor.html')
def criar_aula_professor():
    return render_template('criaraula-professor.html')

@app.route('/editaraula-professor.html')
def editar_aula_professor():
    return render_template('editaraula-professor.html')

@app.route('/PaginaProfessorRelatorios.html')
def pagina_professor_relatorios():
    return render_template('PaginaProfessorRelatorios.html')

@app.route('/editar-admin.html')
def editar_admin():
    return render_template('editar-admin.html')



@app.route('/criarusuario', methods=["POST"])
def criarusuario():
    nome = request.form['nome']
    email = request.form['email']
    senha = request.form['senha']
    telefone = request.form['telefone']
    cpf = request.form['CPF']
    cursor = con.cursor()





    # Verificação de senha forte (sem regex)
    def senha_forte(senha):
        if len(senha) < 8:
            return False
        tem_maiuscula = any(c.isupper() for c in senha)
        tem_minuscula = any(c.islower() for c in senha)
        tem_numero = any(c.isdigit() for c in senha)
        tem_especial = any(not c.isalnum() for c in senha)
        return tem_maiuscula and tem_minuscula and tem_numero and tem_especial

    if not senha_forte(senha):
        flash('A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.', "error")
        return redirect(url_for('cadastro'))

    try:
        cursor.execute('SELECT 1 FROM USUARIO WHERE EMAIL = ?', (email,))
        if cursor.fetchone():
            flash('Esse usuário já está cadastrado.', "error")
            return redirect(url_for('cadastro'))

        senha_hash = generate_password_hash(senha).decode('utf-8')
        cursor.execute('''
            INSERT INTO USUARIO (NOME, EMAIL, SENHA, TELEFONE, CPF, TIPO, TENTATIVAS, SITUACAO)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (nome, email, senha_hash, telefone, cpf, 1, 0, 0))

        con.commit()
        flash('Usuário cadastrado com sucesso.', 'success')

    finally:
        cursor.close()

    return redirect(url_for('cadastro'))

@app.route('/abrir_cadastro_admin')
def cadastro_admin():
    return render_template('cadastro-admin.html')


@app.route('/criarusuario_admin', methods=["POST"])
def criarusuario_admin():
    nome = request.form['nome']
    email = request.form['email']
    senha = request.form['senha']
    telefone = request.form['telefone']
    cpf = request.form['CPF']
    cursor = con.cursor()





    # Verificação de senha forte (sem regex)
    def senha_forte(senha):
        if len(senha) < 8:
            return False
        tem_maiuscula = any(c.isupper() for c in senha)
        tem_minuscula = any(c.islower() for c in senha)
        tem_numero = any(c.isdigit() for c in senha)
        tem_especial = any(not c.isalnum() for c in senha)
        return tem_maiuscula and tem_minuscula and tem_numero and tem_especial

    if not senha_forte(senha):
        flash('A senha deve ter no mínimo 8 caracteres, com pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial.', "error")
        return redirect(url_for('cadastro'))

    try:
        cursor.execute('SELECT 1 FROM USUARIO WHERE EMAIL = ?', (email,))
        if cursor.fetchone():
            flash('Esse usuário já está cadastrado.', "error")
            return redirect(url_for('cadastro'))

        senha_hash = generate_password_hash(senha).decode('utf-8')
        cursor.execute('''
            INSERT INTO USUARIO (NOME, EMAIL, SENHA, TELEFONE, CPF, TIPO, TENTATIVAS, SITUACAO)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (nome, email, senha_hash, telefone, cpf, 1, 0, 0))

        con.commit()
        flash('Usuário cadastrado com sucesso.', 'success')

    finally:
        cursor.close()

    return redirect(url_for('pagina_admin_usuarios'))

# Edição de usuário
@app.route('/editarusuario/<int:id_usuario>', methods=['GET', 'POST'])
def editarusuario(id_usuario):
    if not 'usuario' in session:
        return redirect(url_for('login'))

    cursor = con.cursor()
    cursor.execute("SELECT ID_USUARIO, NOME, EMAIL, SENHA, TELEFONE, CPF FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
    usuario = cursor.fetchone()
    cursor.close()

    if not usuario:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for('editaraluno'))

    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']
        telefone = request.form['telefone']
        cpf = request.form['CPF']


        if senha:
            hash_senha = generate_password_hash(senha).decode('utf-8')

        else:
            hash_senha = usuario[3]


        cursor = con.cursor()
        cursor.execute("UPDATE USUARIO SET NOME = ?, EMAIL = ?, SENHA = ?, TELEFONE = ?, CPF = ? WHERE ID_USUARIO = ?",
                       (nome, email, hash_senha, telefone, cpf, id_usuario))
        con.commit()
        cursor.close()

        # atualiza
        cursor.execute('''SELECT 
                        ID_USUARIO, 
                        NOME,
                        EMAIL,
                        TELEFONE, 
                        SENHA, 
                        CPF, 
                        TIPO 
         FROM USUARIO WHERE EMAIL = ?''', (email,))

        session['usuario'] = cursor.fetchone() # Atualiza a sessão com os novos dados
        print(session['usuario'])

        flash("Usuário atualizado com sucesso.", 'success')
        return redirect(url_for('pagina_aluno'))

    return render_template('editar-aluno.html', usuario=usuario, titulo='Editar Usuário')

    # Login de usuário

# Edição de usuário-admin
@app.route('/editarusuario_admin/<int:id_usuario>', methods=['GET', 'POST'])
def editarusuario_admin(id_usuario):
    if not 'usuario' in session:
        return redirect(url_for('login'))

    cursor = con.cursor()
    cursor.execute("SELECT ID_USUARIO, NOME, EMAIL, SENHA, TELEFONE, CPF FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
    usuario = cursor.fetchone()
    cursor.close()

    if not usuario:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for('editaraluno'))

    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']
        telefone = request.form['telefone']
        cpf = request.form['CPF']

        if senha:
            hash_senha = generate_password_hash(senha).decode('utf-8')

        else:
            hash_senha = usuario[3]


        cursor = con.cursor()
        cursor.execute("UPDATE USUARIO SET NOME = ?, EMAIL = ?, SENHA = ?, TELEFONE = ?, CPF = ? WHERE ID_USUARIO = ?",
                       (nome, email, hash_senha, telefone, cpf, id_usuario))
        con.commit()
        cursor.close()

        # atualiza
        cursor.execute('''SELECT 
                        ID_USUARIO, 
                        NOME,
                        EMAIL,
                        TELEFONE, 
                        SENHA, 
                        CPF, 
                        TIPO 
         FROM USUARIO WHERE EMAIL = ?''', (email,))

        usuario = cursor.fetchone() # Atualiza a sessão com os novos dados
        print(usuario)
        # print(session['usuario'])

        flash("Usuário atualizado com sucesso.", 'success')
        return redirect(url_for('pagina_admin_usuarios'))

    return render_template('editar-aluno-admin.html', usuario=usuario, titulo='Editar Usuário')



@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        cursor = con.cursor()

        try:
            # Busca apenas pela senha criptografada com base no e-mail
            cursor.execute('''SELECT 
                            ID_USUARIO, 
                            NOME,
                            EMAIL,
                            TELEFONE, 
                            SENHA, 
                            CPF, 
                            TIPO, TENTATIVAS, SITUACAO
             FROM USUARIO WHERE EMAIL = ?''', (email,))
            usuario = cursor.fetchone()

            if not usuario:
                flash('Usuário não encontrado.', "error")
                return redirect(url_for('login'))

            if usuario[8] == 1:
                flash('Usuario esta bloqueado', "error")
                return redirect(url_for('login'))

            senha_armazenada = usuario[4]  # A senha criptografada no banco

            if check_password_hash(senha_armazenada, senha):
                session['usuario'] = usuario  # Armazena o e-mail na sessão
                cursor.execute('UPDATE USUARIO SET TENTATIVAS = 0 WHERE ID_USUARIO = ?', (usuario[0],))
                con.commit()
                flash('Login realizado com sucesso.', "success")

                if usuario[6] == 0:
                    return redirect(url_for('pagina_admin_usuarios'))
                elif usuario[6] == 2:
                    return redirect(url_for('pagina_professor_aulas'))
                return redirect(url_for('home_com_usuario'))
            else:
                cursor.execute('''UPDATE USUARIO SET TENTATIVAS = TENTATIVAS + 1 WHERE ID_USUARIO = ?''', (usuario[0],))
                con.commit()

                tentativas = usuario[7]
                if tentativas >= 2:
                    cursor.execute('UPDATE USUARIO SET SITUACAO = 1 WHERE ID_USUARIO = ?', (usuario[0],))
                    con.commit()
                    flash('Conta bloqueada devido a múltiplas tentativas de login falhadas.', "error")
                    return redirect(url_for('login'))

                else:
                    flash('Você tem {} tentativas restantes.'.format(2 - tentativas), "error")

                flash('Senha incorreta.', "error")
                return redirect(url_for('login'))



        finally:
            cursor.close()

    return render_template('login.html')

@app.route('/logout')
def logout():
    if 'usuario' in session:
        session.pop('usuario', None)
    return redirect(url_for('index'))

@app.route('/pagina_admin_usuarios')
def pagina_admin_usuarios():
    usuariosObtidos = []

    try:
        cursor = con.cursor()
        cursor.execute("SELECT * FROM USUARIO")
        usuariosObtidos = cursor.fetchall()
        cursor.close()
    except Exception as e:
        flash("Houve um erro ao obter usuários.", 'error')

    return render_template('PaginaAdminUsuarios.html', usuariosObtidos=usuariosObtidos)


@app.route('/excluiraluno/<int:id_usuario>')
def excluir_aluno(id_usuario):
    print(id_usuario)
    if not 'usuario' in session:
        return redirect(url_for('login'))

    if not session['usuario'][6] == 0:  # Verifica se o usuário é admin
        flash("Acesso negado. Apenas administradores podem excluir usuários.", 'error')
        return redirect(url_for('pagina_admin_usuarios'))

    try:
        cursor = con.cursor()
        cursor.execute("DELETE FROM USUARIO WHERE ID_USUARIO = ?", (id_usuario,))
        con.commit()
        cursor.close()
    except Exception as e:
        flash("Houve um erro ao excluir o usuário.", 'error')
    return redirect(url_for('pagina_admin_usuarios'))

if __name__ == "__main__":
    app.run(debug=True)